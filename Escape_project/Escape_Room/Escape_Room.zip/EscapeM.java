package package1;

import javax.swing.border.*;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;

import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BorderFactory;
import javax.swing.DropMode;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;	
import javax.swing.JToggleButton;
import javax.swing.JDesktopPane;
import javax.swing.JTextPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JEditorPane;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JInternalFrame;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import javax.swing.border.*;
import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.BorderFactory;
import javax.swing.DropMode;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;	
import javax.swing.JToggleButton;
import javax.swing.JDesktopPane;
import javax.swing.JTextPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JEditorPane;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JInternalFrame;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
import java.awt.event.KeyListener;

/*************************************************************************************************************************************************************************
 * 
 * 
 *								                                        ����ȭ��		
 *		
 *			
 *************************************************************************************************************************************************************************/

public class EscapeM {
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Start_Background.png").getImage());//���� ȭ�� �̹��� �ҷ�����
	static Clip clip;
	static JFrame frame=new JFrame();
	int count=-1;
	int flag=0;
    static int Data_Load=0;
    private JTextField ID_textField;
    static  private JPasswordField Password_textField;
	public  static Object []object=null;
	static boolean music=true;
    public static void Map_Move(Object []arr){
    
    EscapeM.frame.getContentPane().removeAll();
    EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
			
	for(int i=0; i<arr.length; i++)
	{
		EscapeM.frame.getContentPane().add((Container)arr[i]);
	}
		EscapeM.frame.repaint();
	}
    
    static void sound(String file, boolean Loop) {
		// TODO Auto-generated method stub
		try {
		AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(new FileInputStream(file)));

		if ( Loop) {
			clip.loop(-1);
		}
		else 
		clip.stop();

		} catch (Exception e) {

		e.printStackTrace();
		}
	}
	static void Button_Shape(JButton button)
	{

		button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		button.setFocusPainted(false);
	}

/************************************************************************************************************
* 							                     	�����Լ�
* ***********************************************************************************************************/
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EscapeM window = new EscapeM();
					window.frame.setVisible(true);
					frame.setLocationRelativeTo(null);//������ �߾ӿ� ǥ��
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * ���ø����̼� �����
	 */
	
	public EscapeM() {
	
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame.setFocusable(true);
		frame.requestFocus();
			
	    new gamedata();
	    
	    File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Main_bgm.wav");
	    System.out.println(file.exists()); //true
	     
	     try {     
	    	 AudioInputStream stream = AudioSystem.getAudioInputStream(file);
	         clip=AudioSystem.getClip();
	         clip.open(stream);
	         clip.start();
	         sound("C:\\Escape_project\\Escape_Room\\sound\\Main_bgm.wav",true);
	     } catch(Exception e) {
	         
	         e.printStackTrace();
	     }

		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//������ �ΰ� �ֱ�
		frame.setSize(MainPanel.getWidth(),MainPanel.getWidth());
		frame.getContentPane().add(MainPanel);	
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setTitle("�б�Ż��");//���α׷� �̸� ����	
		frame.setBounds(100, 100, 800, 600);//ȭ�� ũ�� ����
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JLabel ID_Label = new JLabel("ID");//ID���̺� ����
		ID_Label.setForeground(new Color(128, 0, 0));//ID �� ����
		ID_Label.setFont(new Font("�ü�ü", Font.PLAIN, 25));//��Ʈ ����
		ID_Label.setBounds(206, 236, 40, 34);//��ġ ����
		MainPanel.add(ID_Label);//ID���̺� �߰�
		
		ID_textField = new JTextField();
		ID_textField.setFont(new Font("���� ����", Font.PLAIN, 20));//��Ʈ ����
		ID_textField.setToolTipText("");
		ID_textField.setBounds(261, 235, 277, 34);//��ġ ����
		MainPanel.add(ID_textField);
		
		ID_textField.setColumns(10);
		
		JLabel Password_Label = new JLabel("Password");//Password ���̺� ����
		Password_Label.setForeground(new Color(128, 0, 0));//Password �� ����
		Password_Label.setFont(new Font("�ü�ü", Font.PLAIN, 25));//�۾�ü ����
		Password_Label.setBounds(143, 293, 110, 34);//��ġ����
		MainPanel.add(Password_Label);//Password���̺� �߰�
			
		Password_textField = new JPasswordField();//��ȣȭ�� Password �ؽ�Ʈ �ʵ� ����
		Password_textField.setBounds(261, 293, 277, 34);
		MainPanel.add(Password_textField);
			
		JButton LoginButton = new JButton("Login");//login ���̺� ����
		LoginButton.setFont(new Font("�ü�ü", Font.PLAIN, 29));//�۾�ü ����
		LoginButton.setForeground(new Color(139, 0, 0));
		LoginButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		LoginButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		LoginButton.setBounds(550, 247, 158, 65);
		MainPanel.add(LoginButton);
	
		LoginButton.setFocusPainted(false);
				
		JButton ID_Find_Button = new JButton("\uC544\uC774\uB514 \uCC3E\uAE30");
		ID_Find_Button.setFocusPainted(false);//IDã�� ��ư �߰�
		ID_Find_Button.addActionListener(new ActionListener() {//IDã�� ��ư ������ �̹�Ʈ �߻�
			
			public void actionPerformed(ActionEvent arg0) {
				new ID_FIND();
			}
		});
		
		LoginButton.addActionListener(new ActionListener() {//�α��� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				String id=ID_textField.getText().trim();
				String pw=Password_textField.getText().trim();
			    
				if(id.equals("Admin")&&pw.equals("123456789"))
				{	    
					JOptionPane.showMessageDialog(null,"�����ڷα���","",JOptionPane.INFORMATION_MESSAGE);
					new gamedata();
				}
				else if(id.equals(""))
				{		
					JOptionPane.showMessageDialog(null,"���̵� �Է����ּ���","",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(pw.equals(""))			
				{
					JOptionPane.showMessageDialog(null,"��й�ȣ�� �Է����ּ���","",JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					  for(int i=0; i<gamedata.table.getRowCount(); i++)
						 {
						  System.out.println(gamedata.table.getRowCount());
							 if(gamedata.table.getValueAt(i, 1).equals(id)&&gamedata.table.getValueAt(i, 2).equals(pw))
							 {
			                  new IN_GAME();//�޴� ȭ�� �̵�
			                  break;                  
							 }
							 else if(i==7) 
							 {
								 
								  System.out.println(gamedata.table.getRowCount());
									 if(gamedata.table.getValueAt(i, 1).equals(id)&&gamedata.table.getValueAt(i, 2).equals(pw))
									 {
										 
									 }
								 JOptionPane.showMessageDialog(null,"���̵� �Ǵ� ��й�ȣ�� ��ġ���� �ʽ��ϴ�.","",JOptionPane.INFORMATION_MESSAGE);
							 }	
						 }
				}    
			}
		});
	        	
		ID_Find_Button.setForeground(Color.WHITE);//�۾� ���� ��� 
		ID_Find_Button.setFont(new Font("�ؽ�Lv1����", Font.BOLD, 12));
		ID_Find_Button.setContentAreaFilled(false);
		ID_Find_Button.setBorderPainted(false);
		ID_Find_Button.setBounds(261, 334, 103, 21);
		MainPanel.add(ID_Find_Button);
		
		JLabel Stick_Label1 = new JLabel("             |");//������(��ȣ)���̺� �߰�
		Stick_Label1.setForeground(Color.WHITE);
		Stick_Label1.setFont(new Font("�ؽ�Lv1����", Font.BOLD, 12));
		Stick_Label1.setBounds(306, 337, 58, 15);
		MainPanel.add(Stick_Label1);
		
		JButton Password_Find_Button = new JButton("\uBE44\uBC00\uBC88\uD638 \uCC3E\uAE30");//Passwordã�� ��ư �߰�
		Password_Find_Button.addActionListener(new ActionListener() {//Passwordã�� ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new PW_FIND();
			}
		});
		
		Password_Find_Button.setFocusPainted(false);
		Password_Find_Button.setForeground(Color.WHITE);
		Password_Find_Button.setFont(new Font("�ؽ�Lv1����", Font.BOLD, 12));
		Password_Find_Button.setContentAreaFilled(false);
		Password_Find_Button.setBorderPainted(false);
		Password_Find_Button.setBounds(351, 334, 115, 21);
		MainPanel.add(Password_Find_Button);
		
		JLabel Stick_Label2 = new JLabel("             |");//������(��ȣ)���̺� �߰�
		Stick_Label2.setForeground(Color.WHITE);
		Stick_Label2.setFont(new Font("�ؽ�Lv1����", Font.BOLD, 12));
		Stick_Label2.setBounds(408, 337, 58, 15);
		MainPanel.add(Stick_Label2);
		
		JButton SignUP_Button = new JButton("\uD68C\uC6D0\uAC00\uC785");//ȸ������ ��ư �߰�
		SignUP_Button.setForeground(Color.WHITE);
		SignUP_Button.setFocusPainted(false);
		SignUP_Button.setFont(new Font("�ؽ�Lv1����", Font.BOLD, 12));
		SignUP_Button.setBounds(454, 334, 87, 21);
		SignUP_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		LoginButton.setFocusPainted(false);
		
		SignUP_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		MainPanel.add(SignUP_Button);
		
		JButton btnNewButton_4 = new JButton("\uAD00\uB9AC\uC790\uAD8C\uD55C");
		btnNewButton_4.setFont(new Font("����", Font.PLAIN, 25));
		btnNewButton_4.setForeground(new Color(128, 128, 128));
		btnNewButton_4.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		btnNewButton_4.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�

		btnNewButton_4.setBounds(-20, 10, 178, 54);
		btnNewButton_4.addActionListener(new ActionListener() {//IDã�� ��ư ������ �̹�Ʈ �߻�
						public void actionPerformed(ActionEvent arg0) {
				new gamedata();
			}
		});
		MainPanel.add(btnNewButton_4);
		ImageIcon icon =new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Option_Sound_Off.png");
	    ImageIcon icon2=new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Option_Sound_On.png");
		JButton btnNewButton_5 = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Option_Sound_On.png"));
		JButton btnNewButton_6 = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Option_Sound_Off.png"));
		btnNewButton_6.setForeground(new Color(128, 128, 128));
		btnNewButton_6.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		btnNewButton_6.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		btnNewButton_6.setBounds(12, 523, 33, 21);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				count++;
                if(count%2==1)				{
                	btnNewButton_5.setIcon(icon2);
				sound("C:\\Escape_project\\Escape_Room\\sound\\Main_bgm.wav",true);
                }
                else {
                	btnNewButton_5.setIcon(icon);
                sound("C:\\Escape_project\\Escape_Room\\sound\\\\Main_bgm.wav",false);
                }
			}
		});
		  
		btnNewButton_5.setForeground(new Color(128, 128, 128));
		btnNewButton_5.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		btnNewButton_5.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		btnNewButton_5.setBounds(12, 490, 92, 54);
		btnNewButton_5.setFocusPainted(false);
		MainPanel.add(btnNewButton_5);
		
		SignUP_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new join();
				
			}
		});
				
	}
}



/************************************************************************************************************
* 							                     	ȸ������ ������ ����
* ***********************************************************************************************************/

class Data
{
   private String ID;
   private String PW;
   private String NAME;
   private int flag;
   
   public Data(String id,String pw,String name) 
   {
	   for(int i=0; i<gamedata.table.getRowCount(); i++)
		 {
			 if(gamedata.table.getValueAt(i, 0).equals(name))
			 {
				JOptionPane.showMessageDialog(null,"�̸��ߺ�","�ߺ��޽���",JOptionPane.INFORMATION_MESSAGE);
                flag=1;
                break;
                
			 }
			if(gamedata.table.getValueAt(i,1).equals(id))
			 {
				JOptionPane.showMessageDialog(null,"���̵��ߺ�","�ߺ��޽���",JOptionPane.INFORMATION_MESSAGE);
				flag=1;
				break;
			 }
			 if(gamedata.table.getValueAt(i,2).equals(pw))
			 {
				JOptionPane.showMessageDialog(null,"��й�ȣ�ߺ�","�ߺ��޽���",JOptionPane.INFORMATION_MESSAGE);
				flag=1;
				break;
			 }		 
		 }
	
	   try {
		   if(flag!=1) {
		    
			   JOptionPane.showMessageDialog(null,"���ԿϷ�","",JOptionPane.INFORMATION_MESSAGE);
		   File file = new File("D:\\Data.txt");
	   FileWriter writer=new FileWriter(file,true);

	   writer.write("\r\n"+name+" "+id+" "+pw);	  
	   writer.flush();

       // ��ü �ݱ�
	   writer.close();
		   }	   
	   }
  catch(Exception e){
       e.printStackTrace();
   }
   }
}

/************************************************************************************************************
* 							                     	ȸ������
* ***********************************************************************************************************/

class join 
{ 
	private static final String JPasswordField = null;
	JFrame frame;	
	private static JPasswordField makePasswordField() {
    JPasswordField pf = new JPasswordField(20);
    pf.setText("tutorialspoint");
    pf.setAlignmentX(Component.RIGHT_ALIGNMENT);
    
    return pf;
    }
	join(){
		frame = new JFrame();
	    frame.getContentPane().setBackground(Color.WHITE);
	    frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//������ �ΰ� �ֱ�
	    frame.getContentPane().setForeground(new Color(119, 136, 153));
	    frame.getContentPane().setLayout(null); 
	    frame.setResizable(false);
	    JLabel lblNewLabel = new JLabel("\uAC00\uC785\uD558\uAE30");
	    lblNewLabel.setFont(new Font("���� ����", Font.PLAIN, 29));
	    lblNewLabel.setBounds(88, 10, 122, 54);
	    frame.getContentPane().add(lblNewLabel);
	    
	    JTextField textArea = new JTextField("\uC774\uB984");
	    textArea.setOpaque(false);
	    textArea.addMouseListener(new MouseAdapter(){
	    	@Override 
	    	public void mouseClicked(MouseEvent e)
	    	{
	    		textArea.setForeground(new Color(3, 7, 0));
	    		textArea.setText("");	
	    		}		
	    	});
	    
	    textArea.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
	    textArea.setForeground(Color.LIGHT_GRAY);
	    textArea.setBounds(59, 74, 177, 29);
	    frame.getContentPane().add(textArea);
	
        JTextField textField = new JTextField("���̵�");
	    textField.setOpaque(false);
	    textField.setForeground(Color.LIGHT_GRAY);
	    textField.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
	    textField.setBounds(59, 130, 177, 29);
	    textField.addMouseListener(new MouseAdapter(){
	    	@Override 
	    	public void mouseClicked(MouseEvent e){
	    		textField.setForeground(new Color(3, 7, 0));
	            textField.setText("");
	            }	
	    	});	
	    frame.getContentPane().add(textField);
	
	    JPasswordField textField_1 =new JPasswordField("��й�ȣ");
	    textField_1.setEchoChar((char)0);
	    textField_1.setOpaque(false);
	    textField_1.setForeground(Color.LIGHT_GRAY);
	    textField_1.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
	    textField_1.setBounds(59, 191, 177, 29);

	    textField_1.addMouseListener(new MouseAdapter(){
	    	@Override 
	    	public void mouseClicked(MouseEvent e){
	    		textField_1.setForeground(new Color(3, 7, 0));
	            textField_1.setText("");
	            textField_1.setEchoChar('*');	
	            }	
	    	});
	    
	    frame.getContentPane().add(textField_1);
	    JButton btnNewButton = new JButton("\uAC00\uC785\uD558\uAE30");
	    btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 12));
	    btnNewButton.setForeground(Color.WHITE);
	    btnNewButton.setBackground(Color.black);
	    btnNewButton.addActionListener(new ActionListener() {//IDã�� ��ư ������ �̹�Ʈ �߻�
	    	public void actionPerformed(ActionEvent arg0) {
	    		String str=textField.getText().trim();     //���̵�
			    String str2=textField_1.getText().trim();  //��й�ȣ
			   String str3=textArea.getText().trim();    //�̸�
			   new Data(str,str2,str3);
			   }
	    	});
	    
	    btnNewButton.setBounds(53, 319, 183, 45);
	    btnNewButton.setFocusPainted(false);//IDã�� ��ư �߰�
	    frame.getContentPane().add(btnNewButton);
	
	    JLabel lblNewLabel_1 = new JLabel("\uC774\uBBF8 \uACC4\uC815\uC774 \uC788\uC2B5\uB2C8\uAE4C?");
	    lblNewLabel_1.setForeground(Color.GRAY);
	    lblNewLabel_1.setBounds(59, 369, 130, 21);
	    frame.getContentPane().add(lblNewLabel_1);
	
	    JLabel lblNewLabel_2 = new JLabel("\uB85C\uADF8\uC778\uD558\uAE30");
	    lblNewLabel_2.setForeground(Color.BLACK);
	    lblNewLabel_2.setBounds(181, 372, 60, 15);
	    frame.getContentPane().add(lblNewLabel_2);
			
	    TextArea textPane_2 = new TextArea();
	    frame.setBounds(100, 100, 305, 464);
	    frame.setLocationRelativeTo(null);//������ �߾ӿ� ǥ��
        frame.setVisible(true);
        }
	}

/************************************************************************************************************
* 							                     	���̵� ã��
* ***********************************************************************************************************/

class ID_FIND
{
	JFrame frame;	
	ID_FIND()
	{
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 342, 320);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);//������ �߾ӿ� ǥ��
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//������ �ΰ� �ֱ�
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514 \uCC3E\uAE30");
		lblNewLabel.setFont(new Font("���� ����", Font.PLAIN, 30));
		lblNewLabel.setBounds(83, 10, 189, 71);
		
		frame.getContentPane().add(lblNewLabel);
		
		JTextField textField = new JTextField();
		textField.setForeground(Color.LIGHT_GRAY);
		textField.setFont(new Font("����", Font.PLAIN, 12));
		textField.setText("�̸�");
		textField.setOpaque(false);
	   
		textField.addMouseListener(new MouseAdapter(){
			@Override 
			public void mouseClicked(MouseEvent e){
				textField.setForeground(new Color(3, 7, 0));
		        textField.setText("");
		        }	
			});
		
		textField.setBounds(61, 104, 203, 21);
		textField.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\uD655\uC778");
	
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 15));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.black);		
		btnNewButton.setFocusPainted(false);
		
		btnNewButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str=textField.getText().trim();
				 for(int i=0; i<gamedata.table.getRowCount(); i++)
				 {
					 if(gamedata.table.getValueAt(i, 0).equals(str))
					 {
						JOptionPane.showMessageDialog(null,gamedata.table.getValueAt(i, 1)+"�Դϴ�","",JOptionPane.INFORMATION_MESSAGE);      
					 }
			}
			}
		});
		btnNewButton.setBounds(61, 160, 203, 45);
		frame.getContentPane().add(btnNewButton);	
		frame.setVisible(true);	
	}
}

/************************************************************************************************************
* 							                     	��й�ȣ ã��
* ***********************************************************************************************************/

class PW_FIND
{
	JFrame frame;

	PW_FIND(){
	frame = new JFrame();
	frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//������ �ΰ� �ֱ�
	frame.setBounds(100, 100, 342, 320);
	frame.setLocationRelativeTo(null);//������ �߾ӿ� ǥ��
	frame.getContentPane().setLayout(null);
	frame.getContentPane().setBackground(Color.WHITE);
	
	JLabel lblNewLabel = new JLabel("\uBE44\uBC00\uBC88\uD638 \uCC3E\uAE30");
	lblNewLabel.setBounds(75, 10, 177, 71);
	frame.getContentPane().add(lblNewLabel);
	lblNewLabel.setFont(new Font("���� ����", Font.PLAIN, 27));

	JTextField	textField = new JTextField();
	textField.setText("\uC774\uB984");
	
	frame.getContentPane().add(textField);
	textField.setColumns(10);
    textField.setOpaque(false);
	textField.setForeground(Color.LIGHT_GRAY);
	textField.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
	textField.setBounds(75, 79, 177, 29);
	textField.addMouseListener(new MouseAdapter(){
		@Override 
		public void mouseClicked(MouseEvent e){
			textField.setText("");
			}
		});
	JTextField textField_1 = new JTextField();
	textField_1.setText("\uC544\uC774\uB514");
	textField_1.setOpaque(false);
	textField_1.setForeground(Color.LIGHT_GRAY);
	textField_1.setColumns(10);
	textField_1.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(0, 0, 0)));
	textField_1.setBounds(75, 118, 177, 29);
    textField_1.addMouseListener(new MouseAdapter()
    {
    	@Override 
    	public void mouseClicked(MouseEvent e){
    		textField_1.setText("");
    		}
    	});

	frame.getContentPane().add(textField_1);
	
	JButton btnNewButton_2 = new JButton("\uD655\uC778\uD558\uAE30");
	btnNewButton_2.setFocusPainted(false);//IDã�� ��ư �߰�
	btnNewButton_2.setBounds(75, 191, 177, 40);
	btnNewButton_2.setFont(new Font("���� ����", Font.PLAIN, 15));
	btnNewButton_2.setForeground(Color.WHITE);
	btnNewButton_2.setBackground(Color.black);
	btnNewButton_2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String str=textField.getText().trim();
			String str2=textField_1.getText().trim();
			 for(int i=0; i<gamedata.table.getRowCount(); i++)
			 {
				 if(gamedata.table.getValueAt(i, 0).equals(str)&&gamedata.table.getValueAt(i, 1).equals(str2))
				 {
					JOptionPane.showMessageDialog(null,gamedata.table.getValueAt(i, 2)+"�Դϴ�","",JOptionPane.INFORMATION_MESSAGE);
        
				 }
			 }
		}
	});
	frame.getContentPane().add(btnNewButton_2);	
	frame.setVisible(true);
	}
}

/*************************************************************************************************************************************************************************
 * 
 * 
 *								                                        �޴�ȭ��	
 *		
 *			
 *************************************************************************************************************************************************************************/

class IN_GAME extends JFrame
{  
	JLabel Menu_Label=new JLabel();
	static ImagePanel Menu_Background=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Menu_Background.png").getImage());//�޴� ��� �̹���
	JButton New_Button = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\New_Menu.png"));
	JButton Rank_Button = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Rank_Menu.png"));
    JButton Exit_Button = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Exit_Menu.png"));
    
	IN_GAME()
	{
		EscapeM.object=null;
	
		New_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		New_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		New_Button.setFocusPainted(false);
		New_Button.setBounds(341, 248, 137, 41);
	
		Rank_Button.addActionListener(new ActionListener() {//�α��� ��ư ������ �̺�Ʈ �߻�
				public void actionPerformed(ActionEvent arg0) {
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Button_Sound.wav");
					System.out.println(file.exists()); //true
					
					try {
						AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					    Clip clip = AudioSystem.getClip();
					    clip.open(stream);
					    clip.start();
					    } catch(Exception e) {
					    	e.printStackTrace();
					     }
					JFrame frame=new JFrame();
				    new Rank(frame);		  	
				}
			});
		New_Button.addActionListener(new ActionListener() {//���ӽ��� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.sound("C:\\Escape_project\\Escape_Room\\sound\\Main_bgm.wav",false);
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Button_Sound.wav");
				System.out.println(file.exists()); //true
				
				try {
					AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				    Clip clip = AudioSystem.getClip();
				    clip.open(stream);
				    clip.start();
				    } catch(Exception e) {
				    	e.printStackTrace();
				     }
				new C817();  	
				}
			});
		Rank_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Rank_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Rank_Button.setFocusPainted(false);
		Rank_Button.setBounds(341, 311, 137, 41);

		Exit_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Exit_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Exit_Button.setFocusPainted(false);
		Exit_Button.setBounds(341, 374, 137, 41);
		
		Exit_Button.addActionListener(new ActionListener() {//�޴� ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Button_Sound.wav");
				System.out.println(file.exists()); //true
				
				try {
					AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				    Clip clip = AudioSystem.getClip();
				    clip.open(stream);
				    clip.start();
				    } catch(Exception e) {
				    	e.printStackTrace();
				     }
				System.exit(0);
			}
		});
	
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.frame.repaint();
		EscapeM.object =new Object[] {New_Button,Rank_Button,Exit_Button,Menu_Background};
		EscapeM.Map_Move(EscapeM.object);
		  
	}
}

/************************************************************************************************************
* 							                     	�޴� ��ŷ ������
* ***********************************************************************************************************/

class gamedata
{
	static JTable table;
	JFrame frame = new JFrame();
	
	gamedata()
	{	
		 table = new JTable(new DefaultTableModel(	 
			 	new Object[][] {
			 		{"xxx","Admin","123456789"}
				},
			 	new String[] {
			 		"�̸�","���̵�","��й�ȣ"
			 	}
			 )); 
		 int j=1;
		 JScrollPane scroll=new JScrollPane(table);
		 frame.getContentPane().add(scroll);
		 String filepath="C:\\Data.txt";
		 int count=0;
		 File file=new File(filepath);
		 try{
			 BufferedReader br=new BufferedReader(new FileReader(file));
			 DefaultTableModel model=(DefaultTableModel)table.getModel();
			 Object []obj= br.lines().toArray();
			 
			 for(int i=0; i<obj.length; i++)
				{
					String line =obj[i].toString().trim();
			
					System.out.println(j);
					String[] datarow=line.split(" ");
				
					model.insertRow(j,datarow);
	
					j++;
				}
			}
			catch(Exception e){	
			}
		 if(EscapeM.Data_Load!=0) {
			 frame.setSize(500,500);
			 frame.setBounds(100, 100, 450, 300);
	         frame.setVisible(true);
	         }
		 EscapeM.Data_Load=1;
		 }
	}

/************************************************************************************************************
* 							                     	�޴� ��ŷȭ��
* ***********************************************************************************************************/

class Rank
{
	JTable table2 = new JTable();
    private JScrollPane scrollPane;
	ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\LankBackground.png").getImage());//���� ȭ�� �̹��� �ҷ�����

	Rank(JFrame frame)
	{		
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton_Menu.png"));
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(662, 514, 107, 36);
		
		EscapeM.frame.setSize(MainPanel.getWidth(),MainPanel.getWidth());
		EscapeM.object=null;
		table2.setFont(new Font("�ؽ�Lv1����", Font.PLAIN, 15));
		table2.setForeground(Color.WHITE);
		table2.setRowHeight(30);
		table2.setBackground(new Color(0,0,0,0));
		table2.setModel(new DefaultTableModel(
				new Object[][] {
					{"\uC21C\uC704","\uACC4\uC815","\uD074\uB9AC\uC5B4\uC2DC\uAC04","\uB0A0\uC9DC"},
				    {"   1", null, null, null},
				    {"   2", null, null, null},
				    {"   3", null, null, null},
				    {"   4", null, null, null},
				    {"   5", null, null, null},
				    {"   6", null, null, null},
				    {"   7", null, null, null},
				    {"   8", null, null, null},
				    {"   9", null, null, null},
				    {"   10", null, null, null},
				    },
				new String[] {
						"\uC21C\uC704", "\uACC4\uC815", "\uD074\uB9AC\uC5B4 \uC2DC\uAC04", "\uB0A0\uC9DC"
						}
				    ));
		table2.getColumnModel().getColumn(0).setPreferredWidth(59);
		table2.getColumnModel().getColumn(1).setPreferredWidth(62);
		table2.getColumnModel().getColumn(2).setPreferredWidth(85);
		table2.getColumnModel().getColumn(3).setPreferredWidth(83);
	    table2.setBounds(145, 160, 500, 550);
        scrollPane = new JScrollPane(table2);
	    MainPanel.setSize(30,30);
	    
	    BackButton.addActionListener(new ActionListener() {//��ŷ ������ ��ư ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Button_Sound.wav");
				System.out.println(file.exists()); //true
				
				try {
					AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				    Clip clip = AudioSystem.getClip();
				    clip.open(stream);
				    clip.start();
				    } catch(Exception e) {
				    	e.printStackTrace();
				     }
				new IN_GAME();
			}
		});
	    
	    EscapeM.frame.getContentPane().removeAll();
	    EscapeM.frame.getContentPane().update(EscapeM.frame.getContentPane().getGraphics());
        EscapeM.frame.setSize(800,600);
	    EscapeM.object=new Object[]{BackButton,table2,MainPanel};
	    EscapeM.Map_Move(EscapeM.object);

	}
}

class ImagePanel extends JPanel{
	private Image img;
	
	public ImagePanel(Image img) {//�̹��� �߰�
		this.img=img;
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));//���� ���� �ִ밪 ����
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);
	}	
	public int getWidth() {
		return img.getWidth(null);
		
	}
	public int getHeight() {
		return img.getHeight(null);
	}
	
	public void paintComponent(Graphics g) {//�̹����� �ڵ����� ������
		g.drawImage(img, 0, 0, null);
	}
}

/*************************************************************************************************************************************************************************
 * 
 * 
 *								                                        �ΰ��� ����		
 *		
 *			
 *************************************************************************************************************************************************************************/

/************************************************************************************************************
* 							                     	�κ��丮
* ***********************************************************************************************************/

class setInventory{ //�κ��丮 ��ġ�� ���� Ŭ����
	static boolean back_of_C817_key = false;
	static boolean beam_usb = false;
	static boolean hammer = false;
	static boolean bbaru = false; // ����
	static boolean paperA = false; // 4�� ȭ��� �� ����
	static boolean paperB = false; // 1�� ���� ���� ����
	static boolean keyA = false; // ��ȭ���� �ִ� Ű, 4�� ������ ���̴� ����
	static boolean keyB = false; // ȭ��� ���� ����, 4�� ������ ���̴� ����
	static boolean keyC = false; // 8�� �繰�� �� �ݰ� �� ����, 4�� ������ ���̴� ����
	static JPanel first=new JPanel();
	static JPanel second=new JPanel();
	static JPanel third =new JPanel();
	static JPanel fourth=new JPanel();
	static JPanel fifth=new JPanel();
	static JPanel sixth=new JPanel();
	static JPanel sventh=new JPanel();
	static JPanel eighth=new JPanel();
	static int c=-1;
	static Inven_event1 e=new Inven_event1();
	JButton button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\CellPhone.png"));
	
	setInventory(JButton item){  	
		Container contentpane=first.getRootPane();
		
		if(0==first.getComponentCount())
		{
			first.setBounds(208,510,40,40);
			item.setBounds(3,3,40,40);
			first.add(item);
		}
		else if(0==second.getComponentCount())
		{
			second.setBounds(255,510,40,40);
			item.setBounds(3,3,40,40);
			second.add(item);
		
		}
		else if(0==third.getComponentCount())
		{
			third.setBounds(304,510,40,40);
			item.setBounds(3,3,40,40);
			third.add(item);
		}
		else if(0==fourth.getComponentCount())
		{
			fourth.setBounds(352,510,40,40);
		      item.setBounds(3,3,40,40);
			fourth.add(item);
		}
		else if(0==fifth.getComponentCount())
		{
			fifth.setBounds(403,510,40,40);
			item.setBounds(3,3,40,40);
			fifth.add(item);
		}
		else if(0==sixth.getComponentCount())
		{
			sixth.setBounds(450,510,40,40);
			item.setBounds(3,3,40,40);
			sixth.add(item);
		}
		
		else if(0==sventh.getComponentCount())
		{	
			sventh.setBounds(500,510,40,40);
		    item.setBounds(3,3,40,40);
			sventh.add(item);
		}
		else if(0==eighth.getComponentCount())
		{
			eighth.setBounds(548,510,40,40);
		     item.setBounds(3,3 ,40,40);
			eighth.add(item);
		}
		
	 EscapeM.frame.getContentPane().repaint();	
	}
}

/************************************************************************************************************
* 							                     	�κ��丮 �̺�Ʈ1
* ***********************************************************************************************************/

class Inven_event1
{
	public Inven_event1()
	{
		Toilet. phone2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(true) {
					Toilet.c++;
		
					if(0==Toilet.c%2){
						new Phone();
						}
					else {
						EscapeM.frame.getContentPane().removeAll();
						EscapeM.frame.getContentPane().repaint();
						for(int i=0; i<EscapeM.object.length; i++)
						{
							EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
						}
						EscapeM.frame.getContentPane().repaint();	 
					}
					}			
				}
			});
		}
}

/************************************************************************************************************
* 							                     	�κ��丮 �̺�Ʈ2
* ***********************************************************************************************************/

class Inven_event2
{
	static int f=-1;
	static ImagePanel hint1=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Vault_Password_Hint1_Background.png").getImage());//�޴� ��� �̹���
	
	public Inven_event2()
	{
		Floor1_Hallway.Vault_Password_Hint1_Desk_Button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(true) {
					f++;				//	EscapeM.Map_Move(EscapeM.object);
					if(0==f%2){
						EscapeM.frame.getContentPane().removeAll();
						EscapeM.frame.getContentPane().repaint();
						hint1.setBounds(200,100,100,100);
						EscapeM.frame.getContentPane().add(hint1);
							
						for(int i=0; i<EscapeM.object.length; i++)
						{
							EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
						}
						EscapeM.frame.getContentPane().repaint();	 
						}
					else {
						EscapeM.frame.getContentPane().removeAll();
						EscapeM.frame.getContentPane().repaint();
						
						for(int i=0; i<EscapeM.object.length; i++)
						{
							EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
						}
						EscapeM.frame.getContentPane().repaint();	
						}
					}
				}
			});
		}
}
	   
/************************************************************************************************************
* 							                     	�κ��丮 �̺�Ʈ3
* ***********************************************************************************************************/

class Inven_event3
{
	static int f3=-1;
	static ImagePanel hint2=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Vault_Password_Hint2_Background.png").getImage());//�޴� ��� �̹���
	
	public Inven_event3()
	{
		Floor4_Hallway.Vault_Password_Hint2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(true) {
				f3++;				//	EscapeM.Map_Move(EscapeM.object);
				if(0==f3%2){
					EscapeM.frame.getContentPane().removeAll();
					EscapeM.frame.getContentPane().repaint();
					hint2.setBounds(200,100,100,100);
					EscapeM.frame.getContentPane().add(hint2);
							
					for(int i=0; i<EscapeM.object.length; i++)
					{
						EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
					}
					EscapeM.frame.getContentPane().repaint();	 
					}
				else {
					EscapeM.frame.getContentPane().removeAll();
				    EscapeM.frame.getContentPane().repaint();
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();	
				}
				}
				}
			});
		}
}

/************************************************************************************************************
* 							                     	�޴���
* ***********************************************************************************************************/

class Phone
{
	static ImagePanel Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Main.png").getImage());
	JPanel panel=new JPanel();
	JButton note=new JButton();
	JButton contect=new JButton();
	JButton currency=new JButton();
	JButton message=new JButton();
	JButton gallery=new JButton();
	JButton option=new JButton();
	JButton note_first=new JButton();
	JButton note_second=new JButton();
	JButton note_third=new JButton();
	JButton main_back=new JButton();
	JButton p1=new JButton();
    JButton p2=new JButton();
	JButton p3=new JButton();
	JButton p4=new JButton();
	JButton p5=new JButton();
	JButton p6=new JButton();
	JButton p7=new JButton();
	JButton p8=new JButton();
	JButton p9=new JButton();
	JButton p10=new JButton();
	JButton p11=new JButton();
	JButton message1=new JButton();
	JButton message2=new JButton();
	JButton message3=new JButton();
	JButton message4=new JButton();
	JButton message5=new JButton();
	JButton gallery1=new JButton();
	JButton gallery2=new JButton();
	JButton gallery3=new JButton();
	JButton gallery4=new JButton();
	JButton gallery5=new JButton();
	JButton option1=new JButton();
	JButton option2=new JButton();
	JButton option3=new JButton();
	JButton option4=new JButton();
	JButton option5=new JButton();
	JButton option6=new JButton();
 
	static int f=1;
	Object []obj=null;
	
	public Phone()
	{
		EscapeM.frame.getContentPane().remove(Toilet.phone);
	    EscapeM.frame.getContentPane().repaint(); 
	    EscapeM.Button_Shape(note);
	    EscapeM.Button_Shape(contect);
	    EscapeM.Button_Shape(currency);
	    EscapeM.Button_Shape(message);
	    EscapeM.Button_Shape(gallery);
	    EscapeM.Button_Shape(option);
	    EscapeM.Button_Shape(note_first);
	    EscapeM.Button_Shape(note_second);
	    EscapeM.Button_Shape(note_third);
	    EscapeM.Button_Shape(main_back);
		EscapeM.Button_Shape(p1);
		EscapeM.Button_Shape(p2);
		EscapeM.Button_Shape(p3);
		EscapeM.Button_Shape(p4);
		EscapeM.Button_Shape(p5);
		EscapeM.Button_Shape(p6);
		EscapeM.Button_Shape(p7);
		EscapeM.Button_Shape(p8);
		EscapeM.Button_Shape(p9);
		EscapeM.Button_Shape(p10);
		EscapeM.Button_Shape(p11);
		EscapeM.Button_Shape(message1);
		EscapeM.Button_Shape(message2);
		EscapeM.Button_Shape(message3);
		EscapeM.Button_Shape(message4);
		EscapeM.Button_Shape(message5);
		EscapeM.Button_Shape(gallery1);
		EscapeM.Button_Shape(gallery2);
		EscapeM.Button_Shape(gallery3);
		EscapeM.Button_Shape(gallery4);
		EscapeM.Button_Shape(gallery5);
		EscapeM.Button_Shape(option1);
		EscapeM.Button_Shape(option2);
		EscapeM.Button_Shape(option3);
		EscapeM.Button_Shape(option4);
		EscapeM.Button_Shape(option5);
		EscapeM.Button_Shape(option6);
		
	    Main.setLayout(null);
	    Main.setLocation(305,29);
	
		note.setBounds(44, 110, 37, 39);
		contect.setBounds(90, 110, 37, 39);
		message.setBounds(90,351,37,39);
		currency.setBounds(44, 355, 37, 39);
		gallery.setBounds(137, 353, 37, 39);
		option.setBounds(180, 353, 37, 39);
	
		Main.add(note);
		Main.add(contect);
		Main.add(currency);
		Main.add(gallery);
		Main.add(message);
		Main.add(option);
		
		main_back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Main.png").getImage());
				Main.setLocation(305,29);
				Main.add(note);
				Main.add(contect);
				Main.add(currency);
				Main.add(gallery);
				Main.add(message);
				Main.add(option);
			 
				EscapeM.frame.getContentPane().removeAll();
			    EscapeM.frame.getContentPane().repaint();
			    EscapeM.frame.getContentPane().add(Main);
			    
			    for(int i=0; i<EscapeM.object.length; i++)
			    {
			    	EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
			    }
			    EscapeM.frame.getContentPane().repaint();
				}
		});
		
		note.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Notes.png").getImage());
				f=0;
				main_back.setBounds(31,97,26,23);
				Main.setLocation(305,29);
				note_first.setBounds(37,147,186,59);
				note_second.setBounds(38,216,186,69);
				note_third.setBounds(38,298,186,83);
				Main.add(note_first);
				Main.add(note_second);
				Main.add(note_third);
				Main.add(main_back);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					

				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
			    }
			});
		
		note_first.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Notes_Content1.png").getImage());
				f=0;
				
				note.setBounds(31,97,26,23);
				Main.setLocation(305,29);
				Main.add(note);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		note_second.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Notes_Content2.png").getImage());
				note.setBounds(31,97,26,23);
				Main.add(note);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		note_third.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Notes_Content3_Password.png").getImage());
				JPasswordField password = new JPasswordField();
				note.setBounds(31,97,26,23);
				password.setBounds(58, 167, 147, 29);
				Main.add(note);
				Main.add(password);
				Main.setLocation(305,29);
			
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		 message.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message.png").getImage());
				 main_back.setBounds(31,97,26,23);
				 f=0;
				 message1.setBounds(31, 173, 196, 38);
	             message2.setBounds(32, 214, 196, 46);
	             message3.setBounds(31, 263, 196, 41);
	             message4.setBounds(31, 309, 196, 41);
	             message5.setBounds(31, 358, 196, 41);
	             Main.add(main_back);
	             Main.add(message1);
	             Main.add(message2);
	             Main.add(message3);
	             Main.add(message4);
	             Main.add(message5);
				 Main.setLocation(305,29);
				 Main.add(main_back);
		
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		 
		 message1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message_LMH.png").getImage());
				 message.setBounds(31,97,26,23);
				 Main.add(message);
				 Main.setLocation(305,29);
		
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
						
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}	
		 	});
		 
		 message2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message_1588.png").getImage());
				 message.setBounds(31,97,26,23);
				 Main.add(message);
				 Main.setLocation(305,29);
			
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
		
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}	
			 });
		 
		 message3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message_070.png").getImage());
				 message.setBounds(31,97,26,23);
				 Main.add(message);
				 Main.setLocation(305,29);
					
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}	
		 	});

		 message4.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message_HKS.png").getImage());
				 message.setBounds(31,97,26,23);
				 Main.add(message);
				 Main.setLocation(305,29);
			
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}	
		 	});
		 
		 message5.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Message_222.png").getImage());
				 message.setBounds(31,97,26,23);
				 Main.add(message);
				 Main.setLocation(305,29);
				
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				 
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();		
				 }	
		 	});				
		  
		 gallery.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary.png").getImage());
				 Main.add(main_back);
				 f=0;
				 Main.setLocation(305,29);
				 gallery1.setBounds(31, 132, 65, 68);
				 gallery2.setBounds(96, 134, 65, 68);
				 gallery3.setBounds(163, 133, 65, 68);
				 gallery4.setBounds(31, 203, 65, 68);
				 gallery5.setBounds(98, 204, 65, 68);
				 Main.add(gallery1);
				 Main.add(gallery2);
				 Main.add(gallery3);
				 Main.add(gallery4);
				 Main.add(gallery5);
				 Main.add(main_back);
			
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);

				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }	
			 });	
		 
		 gallery1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary1.png").getImage());
				 gallery.setBounds(31,97,26,23);
				 Main.setLocation(305,29);
				 Main.add(gallery);
					
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
			
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
			 });
		 
		 gallery2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary2.png").getImage());
				 gallery.setBounds(31,97,26,23);
				 Main.setLocation(305,29);
				 Main.add(gallery);
					
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
						
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
			 });
		 
		 gallery3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary3.png").getImage());
				 gallery.setBounds(31,97,26,23);
				 Main.setLocation(305,29);
				 Main.add(gallery);
				
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
			
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 } 
			 });
		 
		 gallery4.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary4.png").getImage());
				 gallery.setBounds(31,97,26,23);
				 Main.setLocation(305,29);
				 Main.add(gallery);
		
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
						
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
		 	});
		 
		 gallery5.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Gallary5.png").getImage());
				 gallery.setBounds(31,97,26,23);
				 Main.setLocation(305,29);
				 Main.add(gallery);
					
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
			 });
		 
		 option.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting.png").getImage());
                 f=0;
                 main_back.setBounds(31,97,26,23);
                 Main.add(main_back);
                 
                 EscapeM.frame.getContentPane().removeAll();
      			 EscapeM.frame.getContentPane().repaint();
      			 EscapeM.frame.getContentPane().add(Main);
      		
      			 for(int i=0; i<EscapeM.object.length; i++)
      			 {
      				 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
      			 }
      			 EscapeM.frame.getContentPane().repaint();
      			 Main.setLocation(305,29);
      			 option1.setBounds(31, 165, 195, 30);
      			 option2.setBounds(31, 206, 195, 30);
      			 option3.setBounds(31, 241, 195, 30);
      			 option4.setBounds(31, 284, 195, 40);
      			 option5.setBounds(31, 320, 195, 34);
      			 option6.setBounds(31, 355, 195, 41);
      			 Main.add(option1);
      			 Main.add(option2);
      			 Main.add(option3);
      			 Main.add(option4);
      			 Main.add(option5);
      			 Main.add(option6);
      			 }
			 });
		 
		 option1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_Wifi.png").getImage());
                 f=0;
                 Main.setLocation(305,29);
                 option.setBounds(31,97,26,23);
                 Main.add(option);
                   
                 EscapeM.frame.getContentPane().removeAll();
                 EscapeM.frame.getContentPane().repaint();
                 EscapeM.frame.getContentPane().add(Main);
   				
                 for(int i=0; i<EscapeM.object.length; i++)
                 {
                	 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
                 }
                 EscapeM.frame.getContentPane().repaint();
                 }
			 });
		 
		 option2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_Background.png").getImage());
				 f=0;
				 Main.setLocation(305,29);
				 option.setBounds(31,97,26,23);
				 Main.add(option);
                
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
					}
			 });
		 
		 option3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_Display.png").getImage());
				 f=0;
				 Main.setLocation(305,29);
				 Main.setLocation(305,29);
				 option.setBounds(31,97,26,23);
				 Main.add(option);
               
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
			
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
					}
			 });
		 
		 option4.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_SoftUpdate.png").getImage());
				 f=0;
				 Main.setLocation(305,29);
				 option.setBounds(31,97,26,23);
				 Main.add(option);
             
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
			
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
		 	});
		 
		 option5.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_Information.png").getImage());
				 f=0;
				 Main.setLocation(305,29);
				 option.setBounds(31,97,26,23);
				 Main.add(option);
             
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
				
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
			 });
		 
		 option6.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_Setting_Developer.png").getImage());
				 f=0;
				 Main.setLocation(305,29);
				 option.setBounds(31,97,26,23);
				 Main.add(option);
          
				 EscapeM.frame.getContentPane().removeAll();
				 EscapeM.frame.getContentPane().repaint();
				 EscapeM.frame.getContentPane().add(Main);
			
	
				 for(int i=0; i<EscapeM.object.length; i++)
				 {
					 EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				 }
				 EscapeM.frame.getContentPane().repaint();
				 }
			 });
		 
		contect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber.png").getImage());
				p1.setBounds(31, 124, 199, 30);
				p2.setBounds(31, 149, 199, 30);
				p3.setBounds(31,174,199,30);
				p4.setBounds(31,199,199,30);
				p5.setBounds(31,224,199,30);
				p6.setBounds(31,249,199,30);
				p7.setBounds(31,274,199,30);
				p8.setBounds(31,299,199,30);
				p9.setBounds(31,324,199,30);
				p10.setBounds(31,349,199,30);
				p11.setBounds(31,374,199,30);
				f=0;
				Main.add(p1);
				Main.add(p2);
				Main.add(p3);
				Main.add(p4);
				Main.add(p5);
				Main.add(p6);
				Main.add(p7);
				Main.add(p8);
				Main.add(p9);
				Main.add(p10);
				Main.add(p11);
				main_back.setBounds(31,97,26,23);
				Main.add(main_back);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_KNH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_KSH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
		
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_KLH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_BCS.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
			
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_SAH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
			
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_LMJ.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_LMH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
			
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_LSH.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);

				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
			
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_CHW.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
		
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
			
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_CHW.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
			
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		p11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_ContactNumber_HKS.png").getImage());
				f=0;
				contect.setBounds(31,97,26,23);
				Main.add(contect);
				Main.setLocation(305,29);
				
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
					
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});

		currency.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Main=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/CellPhone_CallLog.png").getImage());
				f=0;
				main_back.setBounds(31,97,26,23);
				Main.add(main_back);
				Main.setLocation(305,29);
			
				EscapeM.frame.getContentPane().removeAll();
				EscapeM.frame.getContentPane().repaint();
				EscapeM.frame.getContentPane().add(Main);
						
				for(int i=0; i<EscapeM.object.length; i++)
				{
					EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
				}
				EscapeM.frame.getContentPane().repaint();
				}
			});
		
		    EscapeM.frame.getContentPane().removeAll();
		    EscapeM.frame.getContentPane().repaint();
		    EscapeM.frame.getContentPane().add(Main);
			
	
		for(int i=0; i<EscapeM.object.length; i++)
		{
			EscapeM.frame.getContentPane().add((Container)EscapeM.object[i]);
		}
		EscapeM.frame.getContentPane().repaint();	
	}
}

/************************************************************************************************************
* 							                     	817ȣ
* ***********************************************************************************************************/

class C817 { // ù ���������� 817ȣ ����
	static JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));
	ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Class817.png").getImage());//817ȣ ȭ�� �̹��� �ҷ�����
    static  Clip clip ;
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
    static int END_KEY1;
    static int END_KEY2;
    static int END_KEY3;
	C817() {
		EscapeM.frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
	
		//�κ��丮 ��ġ
		ItemPanel.setLocation(200, 500);

		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(1, 500, 141, 38);
		
		//�� ��ư ��ġ
		JButton DoorButton=new JButton();
		DoorButton.addActionListener(new ActionListener() {//�� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new DoorOfC817();
			}
		});
		
		DoorButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		DoorButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		DoorButton.setFocusPainted(false);
		DoorButton.setBounds(120, 100, 50, 80);
		
		//�Խ��� ��ư ��ġ
		JButton NoticeButton=new JButton();
		NoticeButton.addActionListener(new ActionListener() {//�Խ��� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new Notice();
			}
		});
		
		NoticeButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		NoticeButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		NoticeButton.setFocusPainted(false);
		NoticeButton.setBounds(50, 90, 40, 50);
		
		//ȭ��Ʈ���� ��ư ��ġ
		JButton WBoardButton=new JButton();
		WBoardButton.addActionListener(new ActionListener() {//ȭ��Ʈ���� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new WhiteBoard();
			}
		});
		
		WBoardButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		WBoardButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		WBoardButton.setFocusPainted(false);
		WBoardButton.setBounds(523, 87, 155, 80);
		
		//���������� ��ũ�� ��ư ��ġ
		JButton ScreenButton=new JButton();
		ScreenButton.addActionListener(new ActionListener() {//ȭ��Ʈ���� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				if (Beam.BeamPower && Beam.Usb) {//������������ ������ �����ְ� usb�� �������� ���
					new Screen();
				}
			}
		});
		
		ScreenButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		ScreenButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		ScreenButton.setFocusPainted(false);
		ScreenButton.setBounds(362, 74, 134, 93);

		//��ǻ�� ��ư ��ġ
		JButton ComputerButton=new JButton();
		ComputerButton.addActionListener(new ActionListener() {//ȭ��Ʈ���� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new ComputerOfC817();
			}
		});
		
		ComputerButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		ComputerButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		ComputerButton.setFocusPainted(false);
		ComputerButton.setBounds(504, 193, 77, 44);
		
		//�� �������� ��ư ��ġ
		JButton BeamButton=new JButton();
		BeamButton.addActionListener(new ActionListener() {//�� �������� ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�������� �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }
				     new Beam();
				}
			});
		
		BeamButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BeamButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BeamButton.setFocusPainted(false);
		BeamButton.setBounds(400, 10, 50, 25);
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new	BackOfC817();	
			}
		});
	
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(-25, 510, 141, 38);
		
		//817ȣ ��� ��ġ
		MainPanel.setLocation(1, 1);
		if (Beam.BeamPower && Beam.Usb) { //������������ ������ �����ְ� usb�� �����ִ� ���
			MainPanel =new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Class817_2.png").getImage());//817ȣ ȭ�� �̹��� �ҷ�����	
		}
		EscapeM.frame.setFocusable(true);
		EscapeM.frame.requestFocus();
	    EscapeM.frame.addKeyListener(new KeyListener() { // List�� �׼Ǹ����ʸ� ����.
	    	public void keyTyped(KeyEvent e) {
	    		System.out.println(e.getKeyChar()+" keyTyped key"); 
           //shift�� ���� ���ȴ��� Ȯ���ϴ� ���
	    		if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE){
             
	    			}
	    		else{
               
	    			}
	    		}
	    	@Override
	    	public void keyReleased(KeyEvent e) {
	    		
	    	}
          // ��� Ű�� ���������� ��ҹ��� ������ ���Ѵ�.
	    	public void keyPressed(KeyEvent e) {
	    		
	    	}
	    	});
	    EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,ItemPanel,NoticeButton,DoorButton,BeamButton,WBoardButton,ComputerButton
	    		,ScreenButton,MainPanel};
        EscapeM.Map_Move(EscapeM.object);
        }
}


/****************************************************************************
 *								 817ȣ ��ǻ��							
 ****************************************************************************/

class ComputerOfC817 { // 817ȣ ��ǻ��
	Clip clip;
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Computer_Login.png").getImage());;
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
	
	ComputerOfC817() {
		EscapeM.object = null;
		JFrame Notice_frame = new JFrame();
		Notice_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Notice_frame.getContentPane().setLayout(null);
		Notice_frame.setBounds(100, 100, 800, 600);
		Notice_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//���̵� ���̺�
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(257, 224, 36, 36);
		
		//��й�ȣ ���̺�
		JLabel lblNewLabel_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(246, 274, 50, 36);
		
		//�α��� ���� �� ���̺�
		JLabel lblNewLabel_2 = new JLabel("\uC554\uD638\uAC00 \uC62C\uBC14\uB974\uC9C0\uC54A\uC2B5\uB2C8\uB2E4.\uB2E4\uC2DC \uC2DC\uB3C4\uD558\uC138\uC694.");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_2.setBounds(257, 321, 264, 29);
		lblNewLabel_2.setVisible(false);
		
		//ID �Է� �ؽ�Ʈ�ʵ�
		JTextField textField = new JTextField();
		textField.setBounds(305, 231, 171, 21);
		textField.setColumns(10);
		
		//Password �Է� �ؽ�Ʈ�ʵ�
		JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(305, 282, 171, 21);
		
		//��ǻ�� �α��� ��ư ��ġ
		JButton LoginButton=new JButton();
		LoginButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				if (textField.getText().equals("deu1234") && textField_1.getText().equals("a1234")) {
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Windows(�α��� ����).wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	   
					new LoggedInComputerOfC817();
				}
				else {
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Windows(�α��� ���н�).wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	   
					lblNewLabel_2.setVisible(true);
				}
			}
		});
		
		LoginButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		LoginButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		LoginButton.setFocusPainted(false);
		LoginButton.setBounds(486, 277, 24, 29);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//��ǻ�� ��� ��ġ
		MainPanel.setLocation(1, 1);
		EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,textField,textField_1,LoginButton,lblNewLabel,lblNewLabel_1,lblNewLabel_2,MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	}
}

/****************************************************************************
 *							817ȣ ��ǻ�� �α��� ���� ��					
 ****************************************************************************/

class LoggedInComputerOfC817{
	Clip clip;
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Computer_Start.png").getImage());;
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
	
	LoggedInComputerOfC817() {
		EscapeM.object = null;
		JFrame Notice_frame = new JFrame();
		Notice_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Notice_frame.getContentPane().setLayout(null);
		Notice_frame.setBounds(100, 100, 800, 600);
		Notice_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�޸���
		ImagePanel MemoPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Computer_File_Text.png").getImage());
		MemoPanel.setLocation(203, 89);
		MemoPanel.setVisible(false);
		JLabel lblNewLabel = new JLabel("\uD14D\uC2A4\uD2B8.txt");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 11));
		lblNewLabel.setBounds(124, 120, 52, 15);
		
		//�޸��� ��ȣ �Է�
		ImagePanel PassPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Computer_File_Password.png").getImage());
		PassPanel.setLocation(203, 130);
		PassPanel.setVisible(false);
		JTextField textField = new JTextField();
		textField.setBounds(278, 199, 184, 23);
		textField.setColumns(10);
		textField.setVisible(false);
		
		//�޸��� Ȯ�ι�ư ��ġ
		JLabel lblNewLabel_1 = new JLabel("\uC554\uD638\uAC00 \uD2C0\uB838\uC2B5\uB2C8\uB2E4.");
		JButton ExitButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Computer_File_Text_Cancel.png"));
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel_1.setBounds(335, 241, 115, 30);
		lblNewLabel_1.setVisible(false);
		JButton PassExitButton = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Computer_File_Text_Cancel.png"));
		JButton PassCheckButton = new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Computer_File_Password_Check.png"));
		PassCheckButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e1) {	         
			         e1.printStackTrace();
			     }	   
				if(textField.getText().equals("583a@b1414")) {
					PassPanel.setVisible(false);
					textField.setVisible(false);
					PassCheckButton.setVisible(false);
					PassExitButton.setVisible(false);
					lblNewLabel_1.setVisible(false);
					MemoPanel.setVisible(true);
					ExitButton.setVisible(true);
				}
				else
					lblNewLabel_1.setVisible(true);
			}
		});
		PassCheckButton.setBounds(492, 182, 70, 52);
		PassCheckButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		PassCheckButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		PassCheckButton.setFocusPainted(false);
		PassCheckButton.setVisible(false);
		
		//�޸��� ��ȣ �Է�â ���� ��ư ��ġ
		PassExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e1) {	         
			         e1.printStackTrace();
			     }	    
				PassPanel.setVisible(false);
				textField.setVisible(false);
				PassCheckButton.setVisible(false);
				PassExitButton.setVisible(false);
				lblNewLabel_1.setVisible(false);
				textField.setText("");
			}
		});
		PassExitButton.setBounds(539, 139, 26, 23);
		PassExitButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		PassExitButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		PassExitButton.setFocusPainted(false);
		PassExitButton.setVisible(false);
		
		
		//�޸��� ���� ��ư ��ġ
		ExitButton.setBounds(544, 92, 20, 20);
		ExitButton.addActionListener(new ActionListener() {//�޸��� ���� ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				MemoPanel.setVisible(false);
				ExitButton.setVisible(false);
			}
		});
		ExitButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		ExitButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		ExitButton.setFocusPainted(false);
		ExitButton.setVisible(false);
		
		//�޸��� ��ư ��ġ
		JButton MemoButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Computer_Icon.png"));
		MemoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				PassPanel.setVisible(true);
				textField.setVisible(true);
				PassCheckButton.setVisible(true);
				PassExitButton.setVisible(true);
			}
		});
		
		MemoButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		MemoButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		MemoButton.setFocusPainted(false);
		MemoButton.setBounds(124, 63, 50, 54);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//��ǻ�� ��� ��ġ
		MainPanel.setLocation(1, 1);
		EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MemoButton,lblNewLabel_1,textField,PassExitButton,PassCheckButton,
				PassPanel,ExitButton,MemoPanel,lblNewLabel,MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	}
}

/************************************************************************************************************
* 							                     	�������� ��
* ***********************************************************************************************************/

class Beam {
	static ImagePanel MainPanel;
// ����������
	
	int count=-1;
	static boolean BeamPower = false; // ���������� ������ư On/Off ���� (�ʱⰪ : Off)
	static boolean Usb = false; //Usb�� �����ִ��� ����

	Beam() {
		EscapeM.object=null;
		JFrame Beam_frame = new JFrame();

		if (Usb) //Usb�� �����ִ� ���
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Beam_Projector2.png").getImage());
		else
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Beam_Projector.png").getImage());
		EscapeM.frame.getContentPane().removeAll();
		ImageIcon icon1=new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Beam_Projector_PowerOFF.png");
		ImageIcon icon2=new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Beam_Projector_PowerOn.png");
		JButton button=new JButton(); //���������� ��ư
		if(BeamPower) 
			button.setIcon(icon2);
		else 
			button.setIcon(icon1);
		
		Beam_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Beam_frame.getContentPane().setLayout(null);
		Beam_frame.setBounds(100, 100, 800, 600);
		
		Beam_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		button.setBounds(192,305,50,80);
		button.setContentAreaFilled(false);
		button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		button.setFocusPainted(false);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BeamPower = BeamPower ? false : true;
				if(BeamPower) {
					button.setIcon(icon2);
				}
				else {
					button.setIcon(icon1);
				}
			}});
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				C817.clip.stop();
				new C817();
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//Usb ���Թ�ư ��ġ
		JButton UsbButton = new JButton();
		UsbButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (setInventory.beam_usb) { //Usb�� �����ִ� ���
					Usb = true;
					MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Beam_Projector2.png").getImage());
					EscapeM.object=new Object[] {C817.ItemPanel,BackButton,button,MainPanel};
					EscapeM.Map_Move(EscapeM.object);
					setInventory.beam_usb = false;
				}
			}
		});
		
		UsbButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		UsbButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		UsbButton.setFocusPainted(false);
		UsbButton.setBounds(399, 311, 16, 36);
		
		//�� �������� ��� ��ġ
		MainPanel.setLocation(1, 1);	
		EscapeM.object=new Object[] {C817.ItemPanel,BackButton,button,UsbButton,MainPanel};
		EscapeM.Map_Move(EscapeM.object);

	}
}

/****************************************************************************
 *								817ȣ ��								
 ****************************************************************************/

class BackOfC817 { // 817ȣ ��
	static ImagePanel MainPanel;
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
	
	BackOfC817() {
		if (LockerOfC817.LockerOpened)  //�繰���� �������� ���
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Back_Class817_Open.png").getImage());
		else
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Back_Class817.png").getImage());
		
		ItemPanel.setLocation(200, 500);
		EscapeM.object = null;
		JFrame BackOfC817_frame = new JFrame();
		BackOfC817_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		BackOfC817_frame.getContentPane().setLayout(null);
		BackOfC817_frame.setBounds(100, 100, 800, 600);
		BackOfC817_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�繰�� ��ư ��ġ
		JButton LockerButton=new JButton();
		LockerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LockerOfC817();	
			}
		});
		
		LockerButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		LockerButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		LockerButton.setFocusPainted(false);
		LockerButton.setBounds(437, 125, 54, 174);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Right_Shifting_Button.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//817ȣ �� ��� ��ġ
		MainPanel.setLocation(1, 1);
			EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,LockerButton,ItemPanel, MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	
	}
}

/****************************************************************************
 *								817ȣ ��	�繰��							
 ****************************************************************************/

class LockerOfC817 { // 817ȣ �� �繰��
	Clip clip;
	static ImagePanel MainPanel;
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
	static boolean LockerOpened = false; // �繰���� �����ִ��� ����

	LockerOfC817() {
		if (LockerOpened) { //�繰���� �������� ���
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Locker_Open.png").getImage());
		}
		else {
			MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Locker.png").getImage());
		}
		EscapeM.object = null;
		JFrame BackOfC817_frame = new JFrame();
		BackOfC817_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		BackOfC817_frame.getContentPane().setLayout(null);
		BackOfC817_frame.setBounds(100, 100, 800, 600);
		BackOfC817_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�κ��丮 ��ġ
		//new setInventory();
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new BackOfC817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//�繰���� �������� ��� Usb ��ư ��ġ
		JButton UsbButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\UsbCable.png"));
		UsbButton.addActionListener(new ActionListener() { //Usb Ŭ�� ��
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	  
				setInventory.beam_usb = true;
				EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton, MainPanel};
				EscapeM.Map_Move(EscapeM.object);
			}
		});
		
		UsbButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		UsbButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		UsbButton.setFocusPainted(false);
		UsbButton.setBounds(498, 406, 67, 82);
		
		//�繰���� �������� ��� ���豸�� ��ư ��ġ
		JButton KeyButton=new JButton();
		KeyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(setInventory.back_of_C817_key) { //�繰�� ���踦 �������� ��� : �繰�� ����
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�繰�� ���� �Ҹ�.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	   
					LockerOpened = true;
					MainPanel = new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Locker_Open.png").getImage());
					EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,UsbButton, MainPanel};
					EscapeM.Map_Move(EscapeM.object);
					setInventory.back_of_C817_key = false;
				}
			}
		});
		
		KeyButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		KeyButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		KeyButton.setFocusPainted(false);
		KeyButton.setBounds(409, 338, 45, 48);
		
		//817ȣ �� ��� ��ġ
		MainPanel.setLocation(1, 1);
		if (LockerOpened && setInventory.beam_usb) { //�繰���� �����ְ�, Usb�� �������� ���
			EscapeM.object=new Object[] {BackButton, MainPanel,ItemPanel};
		}
		else if (LockerOpened) { //�繰���� �����ְ�, Usb�� ���������� ���� ���
			EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,UsbButton, MainPanel};
		}
		else { //�繰���� �������� ���
			EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,KeyButton, MainPanel};
		}
		EscapeM.Map_Move(EscapeM.object);
	
	}
}

/****************************************************************************
 *							   817ȣ ȭ��Ʈ����					
 ****************************************************************************/

class WhiteBoard { // 817ȣ ȭ��Ʈ����
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Whiteboard.png").getImage());
	
	WhiteBoard() {
		EscapeM.object = null;
		JFrame Notice_frame = new JFrame();
		Notice_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Notice_frame.getContentPane().setLayout(null);
		Notice_frame.setBounds(100, 100, 800, 600);
		Notice_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//ȭ��Ʈ���� ��� ��ġ
		MainPanel.setLocation(1, 1);
		EscapeM.object=new Object[] {C817.ItemPanel,BackButton, MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	
	}
}

/****************************************************************************
 *							   817ȣ ��ũ��				
 ****************************************************************************/

class Screen { // 817ȣ ���������� ��ũ��
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Screen.png").getImage());
	
	Screen() {
		EscapeM.object = null;
		JFrame Notice_frame = new JFrame();
		Notice_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Notice_frame.getContentPane().setLayout(null);
		Notice_frame.setBounds(100, 100, 800, 600);
		Notice_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//ȭ��Ʈ���� ��� ��ġ
		MainPanel.setLocation(1, 1);
		EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton, MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	
	}
}

/****************************************************************************
 *								817ȣ �Խ���						
 ****************************************************************************/

class Notice { // 817ȣ �Խ���
	static Clip clip;
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BulletinBoard.png").getImage());
	
	Notice() {
		EscapeM.object = null;
		JFrame Notice_frame = new JFrame();
		Notice_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		Notice_frame.getContentPane().setLayout(null);
		Notice_frame.setBounds(100, 100, 800, 600);
		Notice_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//���� ��ġ
		JButton KeyButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Key.png"));
		KeyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	  
				setInventory.back_of_C817_key = true;
				EscapeM.object = new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton, MainPanel}; // ȭ�鿡�� Ű�� ����
				EscapeM.Map_Move(EscapeM.object);
			}
		});
		
		KeyButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		KeyButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		KeyButton.setFocusPainted(false);
		KeyButton.setBounds(636, 103, 61, 90);
		
		//�Խ��� ��� ��ġ
		MainPanel.setLocation(1, 1);
		if (setInventory.back_of_C817_key) // Ű�� �̹� �������� ���
			EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton, MainPanel};
		else 
			EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,KeyButton,MainPanel};
		
		EscapeM.Map_Move(EscapeM.object);
	}
}

/****************************************************************************
 *								817ȣ ��								
 ****************************************************************************/

class DoorOfC817 { // ��
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Class817_Door.png").getImage());
	static ImagePanel ItemPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room/image\\Inventory.png").getImage());
	
	DoorOfC817() {
		ItemPanel.setLocation(200, 500);
		JFrame DoorOfC817_frame = new JFrame();
		DoorOfC817_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		EscapeM.object=null;
		DoorOfC817_frame.getContentPane().setLayout(null);
		DoorOfC817_frame.setBounds(100, 100, 800, 600);	
		DoorOfC817_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new C817();
				
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(-25, 510, 141, 38);
		
		//����� ��ġ
		JButton DoorLockButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock.png"));
		DoorLockButton.addActionListener(new ActionListener() {//����� ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new DoorLock();
				
			}
		});
		DoorLockButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		DoorLockButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		DoorLockButton.setFocusPainted(false);
		DoorLockButton.setBounds(375, 200, 24, 50);
		
		//�� ��ġ
		JButton DoorButton=new JButton();
		DoorButton.addActionListener(new ActionListener() {//�� ���� �� �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				if (DoorLock.DoorOpened) { // ���� �������� ���
					new Floor8_Hallway(true,true);
				}
			}
		});
		DoorButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		DoorButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		DoorButton.setFocusPainted(false);
		DoorButton.setBounds(207,98,385,327);
		
		//817ȣ �� ��� ��ġ
		MainPanel.setLocation(1, 1);
		
		EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,DoorLockButton,DoorButton,ItemPanel,MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	}
}

/****************************************************************************
 *								817ȣ �����						
 ****************************************************************************/

class DoorLock { // 817ȣ �����
	Clip clip;
	static ImagePanel MainPanel=new ImagePanel(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Class817_DoorLock.png").getImage());
	static String[] DoorLockPass = {""};//�Է��� �н����带 ������ ���ڿ�
	static Boolean DoorOpened = false;//���� ���ȴ��� �������� ����. �ʱⰪ = false(����) 
	
	DoorLock() {
		JButton B1=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number1_Off.png"));
		JButton B2=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number2_Off.png"));
		JButton B3=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number3_Off.png"));
		JButton B4=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number4_Off.png"));
		JButton B5=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number5_Off.png"));
		JButton B6=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number6_Off.png"));
		JButton B7=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number7_Off.png"));
		JButton B8=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number8_Off.png"));
		JButton B9=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number9_Off.png"));
		JButton BA=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_Asterisk_Off.png"));
		JButton B0=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number0_Off.png"));
		JButton BS=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_#_Off.png"));
		JButton DoorLockButton = new JButton();
		
		if (DoorOpened) // ���� �������� ���
			DoorLockButton.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Button_On.png"));
		else
			DoorLockButton.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Button_Off.png"));
		
		EscapeM.object = null;
		JFrame DoorLock_frame = new JFrame();
		DoorLock_frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Escape_project\\Escape_Room\\image\\logo.png"));//�ΰ� ����
		
		DoorLock_frame.getContentPane().setLayout(null);
		DoorLock_frame.setBounds(100, 100, 800, 600);
		DoorLock_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//1~# ��ư ��ġ
		B1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "1 ";
				B1.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number1_On.png"));
			}
		});
		
		B1.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B1.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B1.setFocusPainted(false);
		B1.setBounds(335,124,45,45);
		
		B2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "2 ";
				B2.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number2_On.png"));
			}
		});
		
		B2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B2.setFocusPainted(false);
		B2.setBounds(392,124,45,45);
		
		B3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "3 ";
				B3.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number3_On.png"));
			}
		});
		
		B3.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B3.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B3.setFocusPainted(false);
		B3.setBounds(449,124,45,45);
		
		B4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "4 ";
				B4.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number4_On.png"));
			}
		});
		
		B4.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B4.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B4.setFocusPainted(false);
		B4.setBounds(335,197,45,45);
		
		B5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "5 ";
				B5.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number5_On.png"));
			}
		});
		
		B5.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B5.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B5.setFocusPainted(false);
		B5.setBounds(392,197,45,45);
		
		B6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "6 ";
				B6.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number6_On.png"));
			}
		});
		
		B6.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B6.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B6.setFocusPainted(false);
		B6.setBounds(449,197,45,45);
		
		B7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "7 ";
				B7.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number7_On.png"));
			}
		});
		
		B7.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B7.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B7.setFocusPainted(false);
		B7.setBounds(335,261,45,45);
		
		B8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "8 ";
				B8.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number8_On.png"));
			}
		});
		
		B8.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B8.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B8.setFocusPainted(false);
		B8.setBounds(392,261,45,45);
		
		B9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "9 ";
				B9.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number9_On.png"));
			}
		});
		
		B9.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B9.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B9.setFocusPainted(false);
		B9.setBounds(449,261,45,45);
		
		BA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "* ";
				BA.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_Asterisk_On.png"));
			}
		});
		
		BA.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BA.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BA.setFocusPainted(false);
		BA.setBounds(335,329,45,45);
		
		B0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "0 ";
				B0.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number0_On.png"));
			}
		});
		
		B0.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		B0.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		B0.setFocusPainted(false);
		B0.setBounds(392,329,45,45);
		
		BS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	   
				DoorLockPass[0] += "# ";
				BS.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_#_On.png"));
			}
		});
		
		BS.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BS.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BS.setFocusPainted(false);
		BS.setBounds(449,329,45,45);
		
		DoorLockButton.addActionListener(new ActionListener() { //����� ���������ư Ŭ�� ��
			public void actionPerformed(ActionEvent arg0) {
				if (DoorLockPass[0].equals("7 3 9 1 ")) { //�н����尡 ���� ��
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���ƶ� �� �ݰ� ������.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	   
					DoorOpened = true;
					DoorLockButton.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Button_On.png"));
				}
				else {
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���ƶ� ���н�.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	   
				}
				DoorLockPass[0] = "";
				B1.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number1_Off.png"));
				B2.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number2_Off.png"));
				B3.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number3_Off.png"));
				B4.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number4_Off.png"));
				B5.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number5_Off.png"));
				B6.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number6_Off.png"));
				B7.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number7_Off.png"));
				B8.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number8_Off.png"));
				B9.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number9_Off.png"));
				BA.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_Asterisk_Off.png"));
				B0.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number0_Off.png"));
				BS.setIcon(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\DoorLock_Number_#_Off.png"));
			}
		});
		
		DoorLockButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		DoorLockButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		DoorLockButton.setFocusPainted(false);
		DoorLockButton.setBounds(445,405,45,45);
		
		//�ڷΰ��� ȭ��ǥ ��ġ
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));
		BackButton.addActionListener(new ActionListener() {//�ڷΰ��� ȭ��ǥ ��ư ������ �̹�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new DoorOfC817();	
			}
		});
		
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(650, 500, 141, 38);
		
		//817ȣ ����� ��� ��ġ
		MainPanel.setLocation(1, 1);
		EscapeM.object=new Object[] {C817.ItemPanel,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,B1,B2,B3,B4,B5,B6,B7,B8,B9,BA,B0,BS,DoorLockButton,MainPanel};
		EscapeM.Map_Move(EscapeM.object);
	
	}
}

/************************************************************************************************************
* 							                     	8�� ����
* ***********************************************************************************************************/

class Floor8_Hallway{
	static Clip clip;
	int back=0;
	int back2=0;
	ImagePanel Floor8_Hallway_Center=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Center.png").getImage());//8�� ���� �߾� �̹���
	ImagePanel Floor8_Hallway_Left=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Left.png").getImage());//8�� ���� ���� �̹���
	ImagePanel Floor8_Hallway_Left2=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Left2.png").getImage());//8�� ���� ���� �̹���2
	ImagePanel Floor8_Hallway_Right=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Right.png").getImage());//8�� ���� ������ �̹���
	ImagePanel Floor8_Hallway_Right2=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Right2.png").getImage());//8�� ���� ������ �̹���2
	ImagePanel Floor8_Hallway_Right3=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Hallway_Right3.png").getImage());//8�� ���� ������ �̹���3
	ImagePanel Class811_Front_Door=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Front_Door.png").getImage());//811ȣ ���� �� ȭ�� �̹���
	ImagePanel Floor8_Elevator=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_Elevator.png").getImage());//8�� ���������� �̹���
	ImagePanel Floor8_Hydrant=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Hydrant.png").getImage());//8�� ��ȭ�� �̹���
	ImagePanel Floor8_Hydrant_Open=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Hydrant_In.png").getImage());//8�� ��ȭ�� ���� �̹���
	ImagePanel Hydrant_In_key2=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Hydrant_In_key.png").getImage());//8�� ��ȭ�� ���� �̹���
static JButton In_key2=new JButton(new ImageIcon("C:/Escape_project/Escape_Room/image/Inventory_Gate_Key1.png"));
	
	
	
	Floor8_Hallway(Boolean Change,Boolean Change2) {
		
		In_key2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		In_key2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		In_key2.setFocusPainted(false);
		/************************************************************************************
		 *								  8�� �߾� ���� ���� ��ư							
		 ************************************************************************************/
		JButton Straight_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Straight_Shifting_Button.png"));//4�� �������� ��ư �̹���
		Straight_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Straight_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Straight_Shifting_Button.setFocusPainted(false);
		Straight_Shifting_Button.setBounds(225, 315, 45, 30);
		
		JButton Left_Diagonal_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Diagonal_Shifting_Button.png"));//8�� ���������� ���� ��ư �̹���
		Left_Diagonal_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Left_Diagonal_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Left_Diagonal_Shifting_Button.setFocusPainted(false);
		Left_Diagonal_Shifting_Button.setBounds(33, 378, 45, 30);
		
		JButton Left_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//8�� ���� ���� ���� ��ư �̹���
		Left_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Left_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Left_Shifting_Button.setFocusPainted(false);
		Left_Shifting_Button.setBounds(22, 518, 61, 17);
			
		JButton Right_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Right_Shifting_Button.png"));//8�� ������ ���� ���� ��ư �̹���
		Right_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Right_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Right_Shifting_Button.setFocusPainted(false);
		Right_Shifting_Button.setBounds(699, 518, 61, 17);	
		/************************************************************************************
		 *								  8�� ���� ���� ��ư					
		 ************************************************************************************/
		JButton Floor8_Hallway_Left2_Button=new JButton();//���� ����2 ȭ�� ��ȯ ��ư 
		Floor8_Hallway_Left2_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor8_Hallway_Left2_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor8_Hallway_Left2_Button.setFocusPainted(false);
		Floor8_Hallway_Left2_Button.setBounds(294, 260, 290, 122);
		
		JButton Hydrant_Button=new JButton();//��ȭ�� �̵� ���� ��ư �̹���
		Hydrant_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Hydrant_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Hydrant_Button.setFocusPainted(false);
		Hydrant_Button.setBounds(590, 156, 51, 232);
		
		JButton Hydrant_Open_Button=new JButton();//��ȭ�� ���� ��ư �̹���
		Hydrant_Open_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Hydrant_Open_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Hydrant_Open_Button.setFocusPainted(false);
		Hydrant_Open_Button.setBounds(256, 278, 25, 122);
		
		JButton Break_Hammer_Button=new JButton();//�κ��丮�� ��ġ�� ������ ��ȭ���� ������ ���߸��� ��ư
		Break_Hammer_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Break_Hammer_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Break_Hammer_Button.setFocusPainted(false);
		Break_Hammer_Button.setBounds(459, 202, 39, 57);	
		/************************************************************************************
		 *								  8�� ������ ���� ���� ��ư					
		 ************************************************************************************/
		JButton Floor8_Hallway_Right2_Button=new JButton();//������ ����2 �̵� ��ư
		Floor8_Hallway_Right2_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor8_Hallway_Right2_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor8_Hallway_Right2_Button.setFocusPainted(false);
		Floor8_Hallway_Right2_Button.setBounds(235, 268, 219, 96);
		
		JButton Floor8_Hallway_Right3_Button=new JButton();//������ ����3 �̵� ��ư
		Floor8_Hallway_Right3_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor8_Hallway_Right3_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor8_Hallway_Right3_Button.setFocusPainted(false);
		Floor8_Hallway_Right3_Button.setBounds(282, 274, 236, 102);
		
		JButton Class811_Front_Door_Button=new JButton();//811ȣ ���� �̵� ��ư
		Class811_Front_Door_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Class811_Front_Door_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Class811_Front_Door_Button.setFocusPainted(false);
		Class811_Front_Door_Button.setBounds(79, 109, 83, 307);
	
		JButton Class811_Button=new JButton();//811ȣ �̵� ��ư
		Class811_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Class811_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Class811_Button.setFocusPainted(false);
		Class811_Button.setBounds(348, 160, 114, 250);
		
		JButton Student_Locker_Button=new JButton();//�繰�� �̵� ��ư
		Student_Locker_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Student_Locker_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Student_Locker_Button.setFocusPainted(false);
		Student_Locker_Button.setBounds(33, 189, 33, 63);
		/************************************************************************************
		 *								  8�� ���������� ���� ��ư					
		 ************************************************************************************/
		JButton Floor8_Elevator_Button=new JButton();//���������� ������ �̵��ϴ� ��ư
		Floor8_Elevator_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor8_Elevator_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor8_Elevator_Button.setFocusPainted(false);
		Floor8_Elevator_Button.setBounds(510, 133, 188, 308);	
		/************************************************************************************
		 *								  8�� ��ȭ�� �̵� ���� ��ư						
		 ************************************************************************************/
		JButton Hydrant_BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//�ҹ��� ��ȭ�� �̵� ��ư
		Hydrant_BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Hydrant_BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Hydrant_BackButton.setFocusPainted(false);
		Hydrant_BackButton.setBounds(665, 504, 165, 57);

		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//���� ���� ��ȭ�� �̵� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(-25, 492, 165, 57);
		
		JButton BackButton2=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//������ ���� ��ȭ�� �̵� ��ư
		BackButton2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton2.setFocusPainted(false);
		BackButton2.setBounds(-25, 492, 165, 57);
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		if(Change==true && Change2==true) {
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Straight_Shifting_Button,Left_Diagonal_Shifting_Button,Left_Shifting_Button,Right_Shifting_Button,Floor8_Hallway_Center};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		}
		else if(Change==false && Change2==true) {
			back=0;
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Floor8_Elevator_Button,Floor8_Elevator};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
			Floor8_Elevator_Button.addActionListener(new ActionListener() {//8�� ���������� �̵� ��ư �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ������ �Ҹ�.wav");//��ȭ�� ���� ���� �߰�
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				        clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {
				         
				         e.printStackTrace();
				     }	     
					new Elevator(true);	
				}
			});	
		}
		else if(Change==true && Change2==false) {
			back2=3;
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Student_Locker_Button,Class811_Button,Class811_Front_Door};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ				
		}
		/************************************************************************************
		 *								  8�� ���� ����						
		 ************************************************************************************/
		Left_Shifting_Button.addActionListener(new ActionListener() {//8�� ���� ���� ���� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {	
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Floor8_Hallway_Left2_Button,Floor8_Hallway_Left};
				EscapeM.Map_Move(EscapeM.object);								
			}		
		});	
		
		Floor8_Hallway_Left2_Button.addActionListener(new ActionListener() {//8�� ���� ����2 ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				back=1;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Hydrant_Button,Floor8_Hallway_Left2};
				EscapeM.Map_Move(EscapeM.object);		
			}
		});	
		
		Hydrant_Button.addActionListener(new ActionListener() {//��ȭ�� �̵� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				back=1;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Hydrant_BackButton,Hydrant_Open_Button,Floor8_Hydrant};
				EscapeM.Map_Move(EscapeM.object);		
			}
		});	
		
		Hydrant_Open_Button.addActionListener(new ActionListener() {//��ȭ�� ���� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {	
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\��ȭ�� ���� �Ҹ�.wav");//��ȭ�� ���� ���� �߰�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	     
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Hydrant_BackButton,Break_Hammer_Button,Floor8_Hydrant_Open};
				EscapeM.Map_Move(EscapeM.object);		
			}
		});		
		
		Break_Hammer_Button.addActionListener(new ActionListener() {//�κ��丮�� ��ġ�� ������ ��ȭ���� ���� Ŭ���� �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���� ������ �Ҹ�.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	
			     
				new setInventory(In_key2);
			    C817.END_KEY1=1;
			    
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Hydrant_BackButton,Hydrant_In_key2};
				EscapeM.Map_Move(EscapeM.object);	
				
			}
		});		
		
		Hydrant_BackButton.addActionListener(new ActionListener() {//8�� ���� ����2 ��ȭ�� �ڷΰ��� ��ư ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Hydrant_Button,Floor8_Hallway_Left2};
				EscapeM.Map_Move(EscapeM.object);			
			}
		});	
		
		BackButton.addActionListener(new ActionListener() {//8�� ���� �߾� �̵� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				if(back==0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Straight_Shifting_Button,Left_Diagonal_Shifting_Button,Left_Shifting_Button,Right_Shifting_Button,Floor8_Hallway_Center};
					EscapeM.Map_Move(EscapeM.object);	
				}
				else if(back==1) {
					back=0;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Floor8_Hallway_Left2_Button,Floor8_Hallway_Left};
					EscapeM.Map_Move(EscapeM.object);		
				}
				else if(back==2) {
					back=1;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Hydrant_Button,Floor8_Hallway_Left2};
					EscapeM.Map_Move(EscapeM.object);						
				}
			}
		});			
		/************************************************************************************
		 *								  8������ 4�� �̵�						
		 ************************************************************************************/
		Straight_Shifting_Button.addActionListener(new ActionListener() {//4�� �������� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\��ܼҸ�.wav");//4�� �������� ��� �Ҹ� �߰�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	     
				new Floor4_Hallway(true);//4�� ���� Ŭ���� ȣ��	
			}
		});	
		/************************************************************************************
		 *								  8�� ����������						
		 ************************************************************************************/
		Left_Diagonal_Shifting_Button.addActionListener(new ActionListener() {//8�� ���������� ���� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Floor8_Elevator_Button,Floor8_Elevator};
				EscapeM.Map_Move(EscapeM.object);
				
				BackButton.addActionListener(new ActionListener() {//8�� ���� ����2 ��ȭ�� ������ �̺�Ʈ �߻�
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Hallway_Center};
						EscapeM.Map_Move(EscapeM.object);	
					}
				});	
				Floor8_Elevator_Button.addActionListener(new ActionListener() {//8�� ���� ����2 ��ȭ�� ������ �̺�Ʈ �߻�
					public void actionPerformed(ActionEvent arg0) {
						 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ������ �Ҹ�.wav");//���������� ������ �Ҹ�
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					        clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {
					         
					         e.printStackTrace();
					     }	     
						new Elevator(true);	
					}
				});	
			}
		});	
		/************************************************************************************
		 *								  8�� ������ ����					
		 ************************************************************************************/
		Right_Shifting_Button.addActionListener(new ActionListener() {//8�� ������ ���� ���� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Floor8_Hallway_Right2_Button,Floor8_Hallway_Right};
				EscapeM.Map_Move(EscapeM.object);				
			}	
		});	
		
		Floor8_Hallway_Right2_Button.addActionListener(new ActionListener() {//������ ����2 �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				back2=1;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Hallway_Right3_Button,BackButton2,Floor8_Hallway_Right2};
				EscapeM.Map_Move(EscapeM.object);			
			}
		});	
		
		Floor8_Hallway_Right3_Button.addActionListener(new ActionListener() {//������ ����3 �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				back2=2;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Class811_Front_Door_Button,Floor8_Hallway_Right3};
				EscapeM.Map_Move(EscapeM.object);			
			}
		});	
		
		Class811_Front_Door_Button.addActionListener(new ActionListener() {//811ȣ ���� �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				back2=3;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Student_Locker_Button,Class811_Button,Class811_Front_Door};
				EscapeM.Map_Move(EscapeM.object);			
			}
		});	
		
		Class811_Button.addActionListener(new ActionListener() {//811ȣ �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new C811();			
			}
		});	
		
		Student_Locker_Button.addActionListener(new ActionListener() {//�繰�� �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Locker();	
			}
		});	
			
		BackButton2.addActionListener(new ActionListener() {//������ ���� ��ȭ�� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				if(back2==0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Straight_Shifting_Button,Left_Diagonal_Shifting_Button,Left_Shifting_Button,Right_Shifting_Button,Floor8_Hallway_Center};
					EscapeM.Map_Move(EscapeM.object);			
				}
				else if(back2==1) {
					back2=0;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Floor8_Hallway_Right2_Button,Floor8_Hallway_Right};
					EscapeM.Map_Move(EscapeM.object);		
				}
				else if(back2==2) {
					back2=1;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Floor8_Hallway_Right3_Button,Floor8_Hallway_Right2};
					EscapeM.Map_Move(EscapeM.object);			
				}
				else if(back2==3) {
					back2=2;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton2,Class811_Front_Door_Button,Floor8_Hallway_Right3};
					EscapeM.Map_Move(EscapeM.object);			
				}				
			}
		});			
	}	
}

/************************************************************************************************************
* 							                     	8�� �繰�� & �ݰ�
* **********************************************************************************************************/

class Locker{
	Clip clip;
	ImagePanel Student_Locker=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Student_Locker.png").getImage());//�繰�� �̹���
	ImagePanel Safe=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Safe.png").getImage());//�繰�� �� �ݰ� �̹���
	ImagePanel Safe_Open=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Safe_Open.png").getImage());//���� �ݰ� �̹���
    static JButton key=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Inventory_Gate_Key1.png"));

	Locker(){
		/********************************************************************��****************
		 *								  �繰�� ��ư & �ݰ� ��ư			
		 ************************************************************************************/
		JButton Student_Locker_Button=new JButton();//�繰�� ���� ��ư 
		Student_Locker_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Student_Locker_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Student_Locker_Button.setFocusPainted(false);
		Student_Locker_Button.setBounds(123, 181, 195, 140);
		
		JButton Safe_On_False_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Safe_On_False.png"));//�ݰ� ��й�ȣ ������ ��ư on
		Safe_On_False_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Safe_On_False_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Safe_On_False_Button.setFocusPainted(false);
		Safe_On_False_Button.setBounds(479, 174, 45, 30);
		
		JButton Safe_Off_False_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Safe_Off_False.png"));//�ݰ� ��й�ȣ Ʋ���� ��ư off
		Safe_Off_False_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Safe_Off_False_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Safe_Off_False_Button.setFocusPainted(false);
		Safe_Off_False_Button.setBounds(531, 174, 45, 30);
		
		JButton Safe_Off_On_Button=new JButton();//�ݰ� ��й�ȣ Ʋ���� ��ư on
		Safe_Off_On_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Safe_Off_On_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Safe_Off_On_Button.setFocusPainted(false);
		Safe_Off_On_Button.setBounds(531, 174, 45, 30);	
		/************************************************************************************
		 *								  ������ ��ư		
		 ************************************************************************************/
		JButton Gate_Key3_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Gate_Key3.png"));//���� ����3 ��ư 
		Gate_Key3_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Gate_Key3_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Gate_Key3_Button.setFocusPainted(false);
		Gate_Key3_Button.setBounds(333, 244, 118, 48);
		/**   			                  �ݰ� ��й�ȣ ��ư                                   **/
		int x=47;
		int num1=0,num2=0,num3=0,num4=0;
		JButton[] Safe_Password_Button=new JButton[12];//�ݰ� ��й�ȣ ��ư ���� �׸� ����
		for(int i=0;i<Safe_Password_Button.length;i++) {
			Safe_Password_Button[i]=new JButton();
			Safe_Password_Button[i].setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
			Safe_Password_Button[i].setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
			Safe_Password_Button[i].setFocusPainted(false);
					
			if(i<3) {
				Safe_Password_Button[i].setBounds(463+(x*num1), 224, 33, 36);	
				num1++;
			}
			else if(i>2 && i<6) {
				Safe_Password_Button[i].setBounds(463+(x*num2), 270, 33, 36);
				num2++;
			}
			else if(i>5 && i<9) {
				Safe_Password_Button[i].setBounds(463+(x*num3), 316, 33, 36);
				num3++;
			}
			else {
				Safe_Password_Button[i].setBounds(463+(x*num4), 362, 33, 36);
				num4++;		
			}		
		}
		
		JButton Safe_Open_Button=new JButton();//�ݰ� ���� ��ư
		Safe_Open_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Safe_Open_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Safe_Open_Button.setFocusPainted(false);
		Safe_Open_Button.setBounds(220, 270, 101, 104);	
		/************************************************************************************
		 *								  �� ȭ�� �̵� ��ư				
		 ************************************************************************************/
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//811ȣ �������� �̵��ϴ� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Student_Locker_Button,Student_Locker};//�̹��� ������Ʈ
		EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		/************************************************************************************
		 *								  �繰�� & �ݰ�			
		 ************************************************************************************/
		String Password="10517E";//�ݰ� ��й�ȣ
		String []Password_True=new String[1];
		Password_True[0]="";
	
		Student_Locker_Button.addActionListener(new ActionListener() {//�繰�� ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				for(int i=0;i<Safe_Password_Button.length;i++)
					Safe.add(Safe_Password_Button[i]);//�ݰ� ��й�ȣ ��ư �߰�
				
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Safe_On_False_Button,Safe_Off_False_Button,Safe_Open_Button,Safe};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�繰�� ���� �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	     
			}				
		});	
			
		Safe_Password_Button[0].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password1="1";
				Password_True[0]+=Password1;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[1].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password2="2";
				Password_True[0]+=Password2;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[2].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password3="3";
				Password_True[0]+=Password3;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[3].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password4="4";
				Password_True[0]+=Password4;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[4].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password5="5";
				Password_True[0]+=Password5;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[5].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password6="6";
				Password_True[0]+=Password6;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[6].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password7="7";
				Password_True[0]+=Password7;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[7].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password8="8";
				Password_True[0]+=Password8;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[8].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password9="9";
				Password_True[0]+=Password9;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[9].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String PasswordC="C";
				Password_True[0]+=PasswordC;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[10].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String Password0="0";
				Password_True[0]+=Password0;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		Safe_Password_Button[11].addActionListener(new ActionListener() {//�ݰ� ��й�ȣ ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				String PasswordE="E";
				Password_True[0]+=PasswordE;
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\�ݰ� ��ư �Ҹ�.wav");//�繰�� ���� �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	     
			}
		});	
		
		Safe_Open_Button.addActionListener(new ActionListener() {//�ݰ� �� ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				if(Password.equals(Password_True[0])) {
					 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���ƶ� �� �ݰ� ������.wav");//�繰�� ���� �Ҹ�
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	
				     EscapeM.object=null;
					 EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Gate_Key3_Button,Safe_Open};
					 EscapeM.Map_Move(EscapeM.object);
				}
				else {
					 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���ƶ� ���н�.wav");//�繰�� ���� �Ҹ�
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	
				    	Password_True[0]="";
				}					
			}
		});	
		Gate_Key3_Button.addActionListener(new ActionListener() {//���� ������ �κ��丮�� �̵� 
			public void actionPerformed(ActionEvent arg0) {
				File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			         clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {	         
			         e.printStackTrace();
			     }	  
			    key.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
			    key.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
			    key.setFocusPainted(false);
			     C817.END_KEY3=1;
					EscapeM.frame.getContentPane().remove(Gate_Key3_Button);
					EscapeM.frame.getContentPane().repaint();
					new setInventory(key);
				

					
					
			}				
		});	
		/************************************************************************************
		 *								  811ȣ �������� �̵�				
		 ************************************************************************************/
		BackButton.addActionListener(new ActionListener() {//811ȣ �������� �̵��ϴ� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Floor8_Hallway(true,false);
			}				
		});	
	}
}

/************************************************************************************************************
* 							                     	811ȣ
* ***********************************************************************************************************/

class C811 {
	ImagePanel Class811=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811.png").getImage());//811ȣ �̹���
	ImagePanel Lecture_Desk=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Lecture_Desk.png").getImage());
	static JButton hammer=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Hammer.png"));//��Ź �� �̹���
	static Clip clip;
	C811(){
		/************************************************************************************
		 *								  ��Ź & ��ǻ�� �̵� ��ư				
		 ************************************************************************************/
		JButton Lecture_Desk_Button=new JButton();//��Ź �� �̵� ��ư
		Lecture_Desk_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Lecture_Desk_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Lecture_Desk_Button.setFocusPainted(false);
		Lecture_Desk_Button.setBounds(220, 470, 391, 91);
		
		JButton Class811_Computer_Button=new JButton();//811ȣ ��ǻ�� �̵� ��ư
		Class811_Computer_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Class811_Computer_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Class811_Computer_Button.setFocusPainted(false);
		Class811_Computer_Button.setBounds(707, 255, 75, 97);
		/************************************************************************************
		 *								  ������ ��ư				
		 ************************************************************************************/
		JButton Hammer_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Hammer.png"));//��ġ ������ ��ư
		Hammer_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Hammer_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Hammer_Button.setFocusPainted(false);
		Hammer_Button.setBounds(339, 220, 112, 56);
		/************************************************************************************
		 *								  �� ȭ�� �̵� ��ư				
		 ************************************************************************************/
		JButton Class811_Front_Door_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//811ȣ ���� �̵� ��ư
		Class811_Front_Door_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Class811_Front_Door_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Class811_Front_Door_Button.setFocusPainted(false);
		Class811_Front_Door_Button.setBounds(-25, 492, 165, 57);
		
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//���� �̹��� �ڷΰ��� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);	
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Class811_Front_Door_Button,Lecture_Desk_Button,Class811_Computer_Button,Class811};//�̹��� ������Ʈ
		EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		/************************************************************************************
		 *								  �� ȭ�� �̵� 			
		 ************************************************************************************/
		Class811_Front_Door_Button.addActionListener(new ActionListener() {//811ȣ ���� �̵� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Floor8_Hallway(true,false);
			}	
		});	
		/************************************************************************************
		 *								  ��Ź �� �̵� 			
		 ************************************************************************************/
		Lecture_Desk_Button.addActionListener(new ActionListener() {//��Ź �� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Hammer_Button,Lecture_Desk};//�̹��� ������Ʈ
				EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
			}	
		});
	        hammer.addActionListener(new ActionListener() {//��Ź �� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.frame.getContentPane().remove(Locker.key);	
				EscapeM.frame.getContentPane().repaint();
			}	
		});	
		
		/************************************************************************************
		 *								  ��ǻ�� �̵� 			
		 ************************************************************************************/
		Class811_Computer_Button.addActionListener(new ActionListener() {//��ǻ�� ȭ������ �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Class811_Computer();
			}	
		});	
		/************************************************************************************
		 *								  ��Ź �� ȭ�� �̵�			
		 ************************************************************************************/
		BackButton.addActionListener(new ActionListener() {//��Ź �� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Class811_Front_Door_Button,Lecture_Desk_Button,Class811_Computer_Button,Class811};//�̹��� ������Ʈ
				EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
			}	
		});	
		/************************************************************************************
		 *								  ������ 			
		 ************************************************************************************/
		Hammer_Button.addActionListener(new ActionListener() {//��ġ
			 JButton hammer=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Inventory_Hammer.png"));//��Ź �� �̹���
			 public void actionPerformed(ActionEvent arg0) {
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	  
				 hammer.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
				 hammer.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
				 hammer.setFocusPainted(false);
				 
				 EscapeM.frame.getContentPane().remove(Hammer_Button);
				 EscapeM.frame.getContentPane().repaint();
				 new setInventory(hammer);
			}	
		});	
	}
}

/************************************************************************************************************
* 							                     	811ȣ ��ǻ��
* ***********************************************************************************************************/

class Class811_Computer{
	static  Clip clip ;
	ImagePanel Class811_Computer=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer.png").getImage());//811ȣ ��ǻ�� �̹���
	ImagePanel Class811_Computer_Developer=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_Developer.png").getImage());//��ǻ�� �������̸� ������ �̹���
	ImagePanel Class811_Computer_Developer_File=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_Developer_File.png").getImage());//��ǻ�� ������ �޸��� �̹��� 
	ImagePanel Class811_Computer_Home=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_Home.png").getImage());//��ǻ�� ����ȭ��
	ImagePanel Class811_Computer_Locker=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_Locker.png").getImage());//��ǻ�� �繰���̸� ������ �̹���
	ImagePanel Class811_Computer_Locker_File=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_Locker_File.png").getImage());//��ǻ�� �繰�� �޸��� �̹���
	ImagePanel Class811_Computer_MyPc=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Class811_Computer_MyPc.png").getImage());//��ǻ�� ����Ž���� �̹���
	
	Class811_Computer(){
		/************************************************************************************
		 *								  ��ǻ�� ���� ��ư				
		 ************************************************************************************/	
		JButton Computer_Power_Button=new JButton();//��ǻ�� ���� ��ư 
		Computer_Power_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Computer_Power_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Computer_Power_Button.setFocusPainted(false);
		Computer_Power_Button.setBounds(626, 397, 23, 21);	
		
		JButton MyPc_Button=new JButton();//����ǻ�� ������ �̵� ��ư
		MyPc_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		MyPc_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		MyPc_Button.setFocusPainted(false);
		MyPc_Button.setBounds(178, 111, 45, 45);	
		
		JButton MyPc_Exit_Button=new JButton();//����ǻ�� ���� ���� ��ư
		MyPc_Exit_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		MyPc_Exit_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		MyPc_Exit_Button.setFocusPainted(false);
		MyPc_Exit_Button.setBounds(552, 131, 16, 15);	
		
		JButton Locker_Button=new JButton();//Locker ���� �̵� ��ư
		Locker_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Locker_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Locker_Button.setFocusPainted(false);
		Locker_Button.setBounds(287, 189, 45, 47);
		
		JButton Developer_Button=new JButton();//Developer ���� �̵� ��ư
		Developer_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Developer_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Developer_Button.setFocusPainted(false);
		Developer_Button.setBounds(339, 189, 45, 47);
		
		JButton Locker_Exit_Button=new JButton();//Locker ���� ���� ��ư
		Locker_Exit_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Locker_Exit_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Locker_Exit_Button.setFocusPainted(false);
		Locker_Exit_Button.setBounds(552, 131, 17, 15);	
		
		JButton Locker_File_Button=new JButton();//Locker �޸��� ���� ��ư
		Locker_File_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Locker_File_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Locker_File_Button.setFocusPainted(false);
		Locker_File_Button.setBounds(287, 189, 45, 47);	
		
		JButton Developer_File_Button=new JButton();//Developer �޸��� ���� ��ư
		Developer_File_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Developer_File_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Developer_File_Button.setFocusPainted(false);
		Developer_File_Button.setBounds(287, 189, 45, 47);	
		
		JButton Locker_File_Exit_Button=new JButton();//Locker �޸��� �ݱ� ��ư
		Locker_File_Exit_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Locker_File_Exit_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Locker_File_Exit_Button.setFocusPainted(false);
		Locker_File_Exit_Button.setBounds(531, 136, 17, 15);	
		
		JButton Developer_File_Exit_Button=new JButton();//Developer �޸��� �ݱ� ��ư
		Developer_File_Exit_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Developer_File_Exit_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Developer_File_Exit_Button.setFocusPainted(false);
		Developer_File_Exit_Button.setBounds(531, 136, 17, 15);	
		
		JButton MyPc_Back_Button=new JButton();//����ǻ�ͷ� �̵� ���v 
		MyPc_Back_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		MyPc_Back_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		MyPc_Back_Button.setFocusPainted(false);
		MyPc_Back_Button.setBounds(236, 183, 39, 15);
		/************************************************************************************
		 *								  �� ȭ�� �̵� ��ư				
		 ************************************************************************************/	
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//���� �̹��� �ڷΰ��� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);	
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Computer_Power_Button,Class811_Computer};//�̹��� ������Ʈ
		EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		/************************************************************************************
		 *								  ��ǻ�� ���� �̺�Ʈ			
		 ************************************************************************************/
		Computer_Power_Button.addActionListener(new ActionListener() {//��ǻ�� ������ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Button,Class811_Computer_Home};
					EscapeM.Map_Move(EscapeM.object);
					
					 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Windows(�α��� ����).wav");
				     System.out.println(file.exists()); //true     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				        clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {
				         
				         e.printStackTrace();
				     }	    
			}	
		});
		
		MyPc_Button.addActionListener(new ActionListener() {//��ǻ�� ��PC ������ Ŭ���� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Exit_Button,Locker_Button,Developer_Button,Class811_Computer_MyPc};
				EscapeM.Map_Move(EscapeM.object);
			
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true	     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		MyPc_Exit_Button.addActionListener(new ActionListener() {//��ǻ�� ��PC ���� ���� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Button,Class811_Computer_Home};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		Locker_Button.addActionListener(new ActionListener() {//Locker ���� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Locker_Exit_Button,Locker_File_Button,MyPc_Back_Button,Class811_Computer_Locker};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		Locker_Exit_Button.addActionListener(new ActionListener() {//Locker ���� ���� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Button,Class811_Computer_Home};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		Locker_File_Button.addActionListener(new ActionListener() {//Locker �޸��� ���� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Locker_File_Exit_Button,Class811_Computer_Locker_File};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		Locker_File_Exit_Button.addActionListener(new ActionListener() {//Locker �޸��� �ݱ� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Locker_Exit_Button,Locker_File_Button,MyPc_Back_Button,Class811_Computer_Locker};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});		
		
		MyPc_Back_Button.addActionListener(new ActionListener() {//����ǻ�ͷ� ���ư��� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Exit_Button,Locker_Button,Developer_Button,Class811_Computer_MyPc};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});		
		
		Developer_Button.addActionListener(new ActionListener() {//Developer ���� �̵� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,MyPc_Back_Button,Locker_Exit_Button,Developer_File_Button,Class811_Computer_Developer};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});		
		
		Developer_File_Button.addActionListener(new ActionListener() {//Developer �޸��� ���� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Locker_File_Exit_Button,Developer_File_Exit_Button,Class811_Computer_Developer_File};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});	
		
		Developer_File_Exit_Button.addActionListener(new ActionListener() {//Developer �޸��� �ݱ� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Locker_Exit_Button,Developer_File_Button,MyPc_Back_Button,Class811_Computer_Developer};
				EscapeM.Map_Move(EscapeM.object);
				
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Mouse_Click(������ Ŭ����).wav");
			     System.out.println(file.exists()); //true     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	  
			}	
		});		
		/************************************************************************************
		 *								  ��ǻ�� �� ȭ�� �̵�			
		 ************************************************************************************/
		BackButton.addActionListener(new ActionListener() {//811ȣ ȭ������ �̵�
			public void actionPerformed(ActionEvent arg0) {
				new C811();
			}	
		});	
	}
}

/************************************************************************************************************
* 							                     	����������
* ***********************************************************************************************************/

class Elevator{
	static  Clip clip ;
	ImagePanel Floor8_In_Elevator=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor8_In_Elevator.png").getImage());//8�� ���������� �� �̹���
	ImagePanel Floor1_In_Elevator=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor1_In_Elevator.png").getImage());//1�� ���������� �� �̹���
	ImagePanel Elevator_Number_Plate=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Elevator_Number_Plate.png").getImage());//���������� ��ȣ��
	
	Elevator(Boolean Change){
		/************************************************************************************
		 *								  8�� ���������� ���� ��ư					
		 ************************************************************************************/
		JButton Floor8_Elevator_Out_Button=new JButton();//8�� ���������� ������ ��ư 
		Floor8_Elevator_Out_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor8_Elevator_Out_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor8_Elevator_Out_Button.setFocusPainted(false);
		Floor8_Elevator_Out_Button.setBounds(297, 80, 187, 338);
		
		JButton Floor1_Elevator_Out_Button=new JButton();//1�� ���������� ������ ��ư 
		Floor1_Elevator_Out_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor1_Elevator_Out_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor1_Elevator_Out_Button.setFocusPainted(false);
		Floor1_Elevator_Out_Button.setBounds(297, 80, 187, 338);
		
		JButton Elevator_Number_Plate_Button=new JButton();//���������� ��ȣ�� ȭ������ �̵��ϴ� ��ư
		Elevator_Number_Plate_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Elevator_Number_Plate_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Elevator_Number_Plate_Button.setFocusPainted(false);
		Elevator_Number_Plate_Button.setBounds(564, 109, 67, 187);
		
		JButton Elevator_Floor8_Plate_Button=new JButton();//���������� ��ȣ�� 8�� �̵��ϴ� ��ư
		Elevator_Floor8_Plate_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Elevator_Floor8_Plate_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Elevator_Floor8_Plate_Button.setFocusPainted(false);
		Elevator_Floor8_Plate_Button.setBounds(410, 260, 61, 36);
		
		JButton Elevator_Floor1_Plate_Button=new JButton();//���������� ��ȣ�� 1�� �̵��ϴ� ��ư
		Elevator_Floor1_Plate_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Elevator_Floor1_Plate_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Elevator_Floor1_Plate_Button.setFocusPainted(false);
		Elevator_Floor1_Plate_Button.setBounds(332, 442, 61, 36);
		/************************************************************************************
		 *								  �� ȭ�� �̵� ��ư				
		 ************************************************************************************/
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//���� �̹��� �ڷΰ��� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		if(Change==true) {
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor8_In_Elevator};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		
		}
		else if(Change==false) {
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor1_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor1_In_Elevator};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
			Floor1_Elevator_Out_Button.addActionListener(new ActionListener() {//1�� ���������� ������ �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					new Floor1_Hallway();
				}	
			});	
			Elevator_Number_Plate_Button.addActionListener(new ActionListener() {//��ȣ�� ������ �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Elevator_Floor8_Plate_Button,Elevator_Floor1_Plate_Button,Elevator_Number_Plate};
					EscapeM.Map_Move(EscapeM.object);
					
					BackButton.addActionListener(new ActionListener() {//��ȣ�� ������ ��ư �̺�Ʈ
						public void actionPerformed(ActionEvent arg0) {
							EscapeM.object=null;
							EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
									,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor8_In_Elevator};
							EscapeM.Map_Move(EscapeM.object);
						}				
					});	
					Elevator_Floor8_Plate_Button.addActionListener(new ActionListener() {//���������� 8�� �̵��ϴ� ��ư �̺�Ʈ
						public void actionPerformed(ActionEvent arg0) {
							EscapeM.object=null;
							EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
									,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor8_In_Elevator};
							EscapeM.Map_Move(EscapeM.object);
							
							 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ���� �Ҹ�.wav");//���������� ���� �Ҹ�
						     System.out.println(file.exists()); //true
						     
						     try {
						         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
						        clip= AudioSystem.getClip();
						         clip.open(stream);
						         clip.start();       
						     } catch(Exception e) {
						         
						         e.printStackTrace();
						     }	     
						}				
					});	
					Elevator_Floor1_Plate_Button.addActionListener(new ActionListener() {//���������� 1�� �̵��ϴ� ��ư �̺�Ʈ
						public void actionPerformed(ActionEvent arg0) {
							EscapeM.object=null;
							EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
									,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor1_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor1_In_Elevator};
							EscapeM.Map_Move(EscapeM.object);
							
							 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ���� �Ҹ�.wav");//���������� ���� �Ҹ�
						     System.out.println(file.exists()); //true
						     
						     try {
						         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
						        clip= AudioSystem.getClip();
						         clip.open(stream);
						         clip.start();       
						     } catch(Exception e) {
						         
						         e.printStackTrace();
						     }	     
						}								
					});	
				}		
			});		
		}
		/************************************************************************************
		 *								  �����̺����� �̵� �� ������ ����					
		 ************************************************************************************/
		Floor8_Elevator_Out_Button.addActionListener(new ActionListener() {//8�� ���������� ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Floor8_Hallway(false,true);
			}		
		});	
		Floor1_Elevator_Out_Button.addActionListener(new ActionListener() {//1�� ���������� ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Floor1_Hallway();
			}	
		});	
		
		Elevator_Number_Plate_Button.addActionListener(new ActionListener() {//��ȣ�� ������ �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Elevator_Floor8_Plate_Button,Elevator_Floor1_Plate_Button,Elevator_Number_Plate};
				EscapeM.Map_Move(EscapeM.object);
				
				BackButton.addActionListener(new ActionListener() {//��ȣ�� ������ ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor8_In_Elevator};
						EscapeM.Map_Move(EscapeM.object);
					}				
				});	
				Elevator_Floor8_Plate_Button.addActionListener(new ActionListener() {//���������� 8�� �̵��ϴ� ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor8_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor8_In_Elevator};
						EscapeM.Map_Move(EscapeM.object);
						
						 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ���� �Ҹ�.wav");//���������� ���� �Ҹ�
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					        clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {
					         
					         e.printStackTrace();
					     }	     
					}				
				});	
				Elevator_Floor1_Plate_Button.addActionListener(new ActionListener() {//���������� 1�� �̵��ϴ� ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor1_Elevator_Out_Button,Elevator_Number_Plate_Button,Floor1_In_Elevator};
						EscapeM.Map_Move(EscapeM.object);
						
						 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ���� �Ҹ�.wav");//���������� ���� �Ҹ�
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					        clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {
					         
					         e.printStackTrace();
					     }	     
					}								
				});	
			}		
		});	
	}
}

/************************************************************************************************************
* 							                     	1��
* ***********************************************************************************************************/

class Floor1_Hallway{
	Clip clip;
	static int Back=0;//ȭ�� ��ȯ 
	ImagePanel Floor1_Elevator=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor1_Elevator.png").getImage());//1�� ���������� �̹���
	ImagePanel Floor1_Hallway=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor1_Hallway.png").getImage());//1�� ���� �̹���
	ImagePanel Floor1_Gate=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor1_Gate.png").getImage());//1�� ���� �̹���
	ImagePanel Floor1_Desk=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor1_Desk.png").getImage());//1�� å�� �̹���
	static JButton Vault_Password_Hint1_Desk_Button2=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Vault_Password_Hint1.png"));//���� 
	
	Floor1_Hallway(){
	      new Inven_event2();
		/************************************************************************************
		 *								  8�� ���������� ���� ��ư					
		 ************************************************************************************/
		JButton Floor1_Elevator_Button=new JButton();//���������� ������ �̵��ϴ� ��ư
		Floor1_Elevator_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor1_Elevator_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor1_Elevator_Button.setFocusPainted(false);
		Floor1_Elevator_Button.setBounds(510, 133, 188, 308);
		
		Vault_Password_Hint1_Desk_Button2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Desk_Button2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Desk_Button2.setFocusPainted(false);
		/************************************************************************************
		 *								  1�� ���� �̵� ���� ��ư			
		 ************************************************************************************/
		JButton Floor1_Hallway_Button=new JButton();//1�� ���� �̵� ��ư
		Floor1_Hallway_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor1_Hallway_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor1_Hallway_Button.setFocusPainted(false);
		Floor1_Hallway_Button.setBounds(315, 120, 209, 225);
		/************************************************************************************
		 *								  1�� ������	
		 ************************************************************************************/
		JButton Vault_Password_Hint1_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Vault_Password_Hint1.png"));//å���� ���� 
		Vault_Password_Hint1_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Button.setFocusPainted(false);
		Vault_Password_Hint1_Button.setBounds(484, 294, 29, 27);
		
		JButton Vault_Password_Hint1_Desk_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Vault_Password_Hint1_Desk.png"));//���� 
		Vault_Password_Hint1_Desk_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Desk_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Vault_Password_Hint1_Desk_Button.setFocusPainted(false);
		Vault_Password_Hint1_Desk_Button.setBounds(306, 208, 143, 149);
		
		JButton IronBar_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\IronBar.png"));//���� 
		IronBar_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		IronBar_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		IronBar_Button.setFocusPainted(false);
		IronBar_Button.setBounds(738, 305, 22, 40);
		/************************************************************************************
		 *								  �� ȭ�� �̵� ��ư				
		 ************************************************************************************/
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//���� �̹��� �ڷΰ��� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);
		
		JButton Left_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//1�� ���� �ڷ� ���� ��ư
		Left_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Left_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Left_Shifting_Button.setFocusPainted(false);
		Left_Shifting_Button.setBounds(22, 518, 61, 17);
		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor1_Elevator_Button,Floor1_Elevator};//�̹��� ������Ʈ
		EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		/************************************************************************************
		 *								  �����̺����� �̵� 					
		 ************************************************************************************/
		Floor1_Elevator_Button.addActionListener(new ActionListener() {//1�� ���������� ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\���������� ������ �Ҹ�.wav");//���������� ������ �Ҹ�
			     System.out.println(file.exists()); //true
			     
			     try {
			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			        clip= AudioSystem.getClip();
			         clip.open(stream);
			         clip.start();       
			     } catch(Exception e) {
			         
			         e.printStackTrace();
			     }	     
			     
				new Elevator(false);
			}
		});
		/************************************************************************************
		 *								  1�� ����					
		 ************************************************************************************/
		Floor1_Hallway_Button.addActionListener(new ActionListener() {//1�� �������� ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Vault_Password_Hint1_Button,IronBar_Button,Floor1_Gate};
				EscapeM.Map_Move(EscapeM.object);
				Back=0;
						
				Vault_Password_Hint1_Button.addActionListener(new ActionListener() {//å���� ���̹�ư ������ ȭ����ȯ �̺�Ʈ 
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Vault_Password_Hint1_Desk_Button,Floor1_Desk};
						EscapeM.Map_Move(EscapeM.object);
					}
				});	
				Vault_Password_Hint1_Desk_Button.addActionListener(new ActionListener() {//���� ������ �κ��丮�� ������ ȹ�� �̺�Ʈ 
					public void actionPerformed(ActionEvent arg0) {
						File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					         clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {	         
					         e.printStackTrace();
					     }	  
						new setInventory(Vault_Password_Hint1_Desk_Button2);
						EscapeM.frame.getContentPane().remove(Vault_Password_Hint1_Desk_Button);
						EscapeM.frame.getContentPane().repaint();
						
					}
				});	
				IronBar_Button.addActionListener(new ActionListener() {//���� ������ �κ��丮�� ������ ȹ�� �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						
					}
				});
				BackButton.addActionListener(new ActionListener() {//�ڷ� ���� ��ư
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Vault_Password_Hint1_Button,IronBar_Button,Floor1_Gate};
						EscapeM.Map_Move(EscapeM.object);
						Back=0;
					}
				});
			}
		});
		Left_Shifting_Button.addActionListener(new ActionListener() {//1�� ������ ���� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				if(Back==0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor1_Hallway_Button,Floor1_Hallway};
					EscapeM.Map_Move(EscapeM.object);
					Back=1;
				}
				else if(Back==1) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor1_Elevator_Button,Floor1_Elevator};
					EscapeM.Map_Move(EscapeM.object);
					Back=0;
				}
			}
		});	
	}
}

/************************************************************************************************************
* 							                     	4��
* ***********************************************************************************************************/

class Floor4_Hallway{
	static  Clip clip ;
	static int Back=0;//ȭ�� ��ȯ 
	Boolean Change;
	ImagePanel Floor4_Gate=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Gate.png").getImage());//4�� ���� �̹���
	ImagePanel Floor4_Stairs=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Stairs.png").getImage());//8�� ���� ��� �̹���
	ImagePanel Floor4_Hallway_Right=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Hallway_Right.png").getImage());//4�� ������ ���� �̹���
	ImagePanel Floor4_Toilet_Entrance=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Toilet_Entrance.png").getImage());//4�� ȭ��� ���� �Ա� �̹���
	ImagePanel GarbageBox=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/GarbageBox.png").getImage());//������ ���� �̹���
	static JButton Vault_Password_Hint2_1=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Inventory_Vault_Password_Hint2.png"));//���� �̹��� �ڷΰ��� ��ư
	
	Floor4_Hallway(Boolean Change){
	new Inven_event3();
		/************************************************************************************
		 *								  4�� �߾� ���� ���� ��ư							
		 ************************************************************************************/
		JButton Left_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));//8������ �̵��ϴ� ������� ���� ��ư �̹���
		Left_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Left_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Left_Shifting_Button.setFocusPainted(false);
		Left_Shifting_Button.setBounds(22, 518, 61, 17);
		Vault_Password_Hint2_1.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Vault_Password_Hint2_1.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Vault_Password_Hint2_1.setFocusPainted(false);
		JButton Right_Shifting_Button=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Right_Shifting_Button.png"));//4�� ������ ������ �̵��ϴ� ��ư �̹���
		Right_Shifting_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Right_Shifting_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Right_Shifting_Button.setFocusPainted(false);
		Right_Shifting_Button.setBounds(699, 518, 61, 17);
		
		JButton Floor4_Gate_Lock_Button=new JButton();//4�� ���� �̵� ��ư 
		Floor4_Gate_Lock_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor4_Gate_Lock_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor4_Gate_Lock_Button.setFocusPainted(false);
		Floor4_Gate_Lock_Button.setBounds(225, 181, 165, 174);
		
		JButton Floor4_Stairs_Button=new JButton();//8�� �̵� ��ư
		Floor4_Stairs_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor4_Stairs_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor4_Stairs_Button.setFocusPainted(false);
		Floor4_Stairs_Button.setBounds(33, 211, 416, 197);
		/************************************************************************************
		 *								  4�� ������ ���� ���� ��ư					
		 ************************************************************************************/
		JButton Floor4_Toilet_Entrance_Button=new JButton();//8�� �̵� ��ư
		Floor4_Toilet_Entrance_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor4_Toilet_Entrance_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor4_Toilet_Entrance_Button.setFocusPainted(false);
		Floor4_Toilet_Entrance_Button.setBounds(645, 158, 82, 270);
		
		JButton GarbageBox_Button=new JButton();//������ ���� �̵� ��ư 
		GarbageBox_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		GarbageBox_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		GarbageBox_Button.setFocusPainted(false);
		GarbageBox_Button.setBounds(279, 388, 67, 63);
		
		JButton Floor4_Toilet_In_Button=new JButton();//ȭ��� �̵� ��ư 
		Floor4_Toilet_In_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor4_Toilet_In_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor4_Toilet_In_Button.setFocusPainted(false);
		Floor4_Toilet_In_Button.setBounds(359, 223, 51, 141);
		/************************************************************************************
		 *								  ��ȭ�� �̵� ��ư					
		 ************************************************************************************/
		JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//���� �̹��� �ڷΰ��� ��ư
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(665, 504, 165, 57);
		/************************************************************************************
		 *								  ������ ��ư					
		 ************************************************************************************/
		JButton Vault_Password_Hint2=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Vault_Password_Hint2.png"));//���� �̹��� �ڷΰ��� ��ư
		Vault_Password_Hint2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Vault_Password_Hint2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Vault_Password_Hint2.setFocusPainted(false);
		Vault_Password_Hint2.setBounds(252, 254, 51, 63);
		Vault_Password_Hint2.addActionListener(new ActionListener() {//���� ������ �κ��丮�� ������ ȹ�� �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new setInventory(Vault_Password_Hint2_1);
				EscapeM.frame.getContentPane().remove(Vault_Password_Hint2);
				EscapeM.frame.getContentPane().repaint();
				
			}
		});

		/************************************************************************************
		 *								  �̹��� ������Ʈ						
		 ************************************************************************************/
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		if(Change==true) {//8������ 4�� �̵��� �̹��� ������Ʈ
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Right_Shifting_Button,Floor4_Gate_Lock_Button,Floor4_Gate};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		}
		else if(Change==false) {//ȭ��ǿ��� ȭ��� �Ա� �̵��� �̹��� ������Ʈ
			Back=2;
			Floor4_Toilet_Entrance.add(Left_Shifting_Button);
			Floor4_Toilet_Entrance.add(GarbageBox_Button);
			Floor4_Toilet_Entrance.add(Floor4_Toilet_In_Button);
			
			EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor4_Toilet_Entrance};//�̹��� ������Ʈ
			EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
			
			Floor4_Toilet_Entrance_Button.addActionListener(new ActionListener() {//4�� ȭ��� �Ա��� �̵��ϴ� ��ư �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					Back=2;
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,GarbageBox_Button,Floor4_Toilet_In_Button,Floor4_Toilet_Entrance};
					EscapeM.Map_Move(EscapeM.object);
					}
				});
			GarbageBox_Button.addActionListener(new ActionListener() {//������ �ڽ� ��ư �̺�Ʈ 
				public void actionPerformed(ActionEvent arg0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Vault_Password_Hint2,GarbageBox};
					EscapeM.Map_Move(EscapeM.object);
					}
				});
			BackButton.addActionListener(new ActionListener() {//������ �ڽ� �ڷ� ���� ��ư �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,GarbageBox_Button,Floor4_Toilet_In_Button,Floor4_Toilet_Entrance};
					EscapeM.Map_Move(EscapeM.object);
					}
				});
			Floor4_Toilet_In_Button.addActionListener(new ActionListener() {//ȭ��� ������ �̵��ϴ� ��ư �̺�Ʈ
				public void actionPerformed(ActionEvent arg0) {
					new Toilet();		
					}
				});	
		}			
		/************************************************************************************
		 *								  4�� �߾� ���� �� 8�� �ö󰡴� ���						
		 ************************************************************************************/
		Left_Shifting_Button.addActionListener(new ActionListener() {//8�� ���� ��� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				if(Back==0) {
					EscapeM.object=null;
				    EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor4_Stairs_Button,Floor4_Stairs};
				    EscapeM.Map_Move(EscapeM.object);
				    Back=1;
				}
				else if(Back==1) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Right_Shifting_Button,Floor4_Gate,Floor4_Gate_Lock_Button};
					EscapeM.Map_Move(EscapeM.object);
				    Back=0;
				}	
				else if(Back==2) {
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor4_Toilet_Entrance_Button,Floor4_Hallway_Right};
					EscapeM.Map_Move(EscapeM.object);
				    Back=1;
				}	
				Floor4_Stairs_Button.addActionListener(new ActionListener() {//8������ �̵��ϴ�  ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\��ܼҸ�.wav");//8�� �ö󰡴� ��ܼҸ� �߰�
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					        clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {
					         
					         e.printStackTrace();
					     }	     
						new Floor8_Hallway(true,true);//8������ �̵�
						}
					});
			}
		});
		/************************************************************************************
		 *								  4�� ������ ����					
		 ************************************************************************************/
		Right_Shifting_Button.addActionListener(new ActionListener() {//4�� ������ ������ �̵��ϴ� ��ư
			public void actionPerformed(ActionEvent arg0) {
				Back=1;
				EscapeM.object=null;
				EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
						,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,Floor4_Toilet_Entrance_Button,Floor4_Hallway_Right};
				EscapeM.Map_Move(EscapeM.object);
				
				Floor4_Toilet_Entrance_Button.addActionListener(new ActionListener() {//4�� ȭ��� �Ա��� �̵��ϴ� ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						Back=2;
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,GarbageBox_Button,Floor4_Toilet_In_Button,Floor4_Toilet_Entrance};
						EscapeM.Map_Move(EscapeM.object);
						}
					});
				GarbageBox_Button.addActionListener(new ActionListener() {//������ �ڽ� ��ư �̺�Ʈ 
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,BackButton,Vault_Password_Hint2,GarbageBox};
						EscapeM.Map_Move(EscapeM.object);
						}
					});
				Vault_Password_Hint2.addActionListener(new ActionListener() {//���� ������ ������ ȹ�� �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
					     System.out.println(file.exists()); //true
					     
					     try {
					         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
					         clip= AudioSystem.getClip();
					         clip.open(stream);
					         clip.start();       
					     } catch(Exception e) {	         
					         e.printStackTrace();
					     }	  
					
						}
					});
				BackButton.addActionListener(new ActionListener() {//������ �ڽ� �ڷ� ���� ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						EscapeM.object=null;
						EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Left_Shifting_Button,GarbageBox_Button,Floor4_Toilet_In_Button,Floor4_Toilet_Entrance};
						EscapeM.Map_Move(EscapeM.object);
						}
					});
				Floor4_Toilet_In_Button.addActionListener(new ActionListener() {//ȭ��� ������ �̵��ϴ� ��ư �̺�Ʈ
					public void actionPerformed(ActionEvent arg0) {
						new Toilet();		
						}
					});
				}	
			});
		/************************************************************************************
		 *								  4�� ���� 						
		 ************************************************************************************/
		Floor4_Gate_Lock_Button.addActionListener(new ActionListener() {//4�� ���� �̵��ϴ� ��ư �̺�Ʈ
			public void actionPerformed(ActionEvent arg0) {
				new Floor4_Gate_Lock();
				}
			});
	}
}

/************************************************************************************************************
* 							                     	4�� ���� 
* ***********************************************************************************************************/

class Floor4_Gate_Lock{
	ImagePanel Floor4_Gate_Lock=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Gate_Lock.png").getImage());//4�� ��� ���� �̹���
    JButton end=new JButton();
    
	Floor4_Gate_Lock(){
	end.setBounds(310,240,150,150);
    end.addActionListener(new ActionListener() {//8�� ������ ���� ���� ��ư ������ �̺�Ʈ �߻�
		public void actionPerformed(ActionEvent arg0) {
			if(C817.END_KEY1==1&&C817.END_KEY2==1&&C817.END_KEY3==1)
			{
				new Ending();
			}
		}		
	});

		JButton Floor4_Gate_Lock_BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\BackButton.png"));//8������ �̵��ϴ� ������� ���� ��ư �̹���
		Floor4_Gate_Lock_BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Floor4_Gate_Lock_BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Floor4_Gate_Lock_BackButton.setFocusPainted(false);
		end.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		end.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		end.setFocusPainted(false);
		Floor4_Gate_Lock_BackButton.setBounds(665, 504, 165, 57);
		
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		EscapeM.object =new Object[] {end,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
				,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,Floor4_Gate_Lock_BackButton,Floor4_Gate_Lock};//�̹��� ������Ʈ
		EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
		
		Floor4_Gate_Lock_BackButton.addActionListener(new ActionListener() {//8�� ������ ���� ���� ��ư ������ �̺�Ʈ �߻�
			public void actionPerformed(ActionEvent arg0) {
				new Floor4_Hallway(true);
			}		
		});
		
	}	
	
}

/************************************************************************************************************
* 							                     	����
* ***********************************************************************************************************/

class Ending{
	static Clip clip;
	ImagePanel []Ending= {
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending_Start.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending1.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending2.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending3.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending4.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending5.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending6.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending7.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending8.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending9.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending10.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending11.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending12.png").getImage()),new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Ending13.png").getImage()),
			new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/ClearTime.png").getImage())};
	
	Ending(){
		JButton Check_Button=new JButton();//�޴� ȭ�� �̵� ��ư
		Check_Button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Check_Button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Check_Button.setFocusPainted(false);
		Check_Button.setBounds(306, 280, 190, 41);
		
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
		
		 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\HYP-Release.wav");//���� bmg �߰�
	     System.out.println(file.exists()); //true
	     
	     try {
	         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
	         clip= AudioSystem.getClip();
	         clip.open(stream);
	         clip.start();       
	     } catch(Exception e) {   
	         e.printStackTrace();
	     }	     
	     Thread thread = new Thread(new Runnable(){
	    	 public void run() {
	    		 for(int i=0;i<15;i++) {	
	    			if(i<14) {	
	    				EscapeM.object=null;
	    			    EscapeM.object =new Object[] {Ending[i]};//�̹��� ������Ʈ
	    			    EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ	
	    			}
	    			else {
	    				 File file = new File("C:\\Escape_project\\Escape_Room\\sound\\Button_Sound.wav");
	    			     System.out.println(file.exists()); //true
	    			     
	    			     try {
	    			         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
	    			         clip= AudioSystem.getClip();
	    			         clip.open(stream);
	    			         clip.start();       
	    			     } catch(Exception e) {   
	    			         e.printStackTrace();
	    			     }	  
		    		    EscapeM.object=null;
			    	    EscapeM.object =new Object[] {Check_Button,Ending[i]};//�̹��� ������Ʈ
			    	    EscapeM.Map_Move(EscapeM.object);//�̹��� ������Ʈ		
		    		}
	    			try{
	    				Thread.sleep(4500);
	    			}catch(InterruptedException e){}
	    			}
	    		 }
	    	 });
	    	thread.start();		
	    	/************************************************************************************
			 *								  �޴� �̵� ��ư �̺�Ʈ			
			 ************************************************************************************/	
	    	Check_Button.addActionListener(new ActionListener() {//4�� ������ ���� ��ư �̺�Ʈ �߻�
				public void actionPerformed(ActionEvent arg0) {
				    EscapeM.sound("C:\\Escape_project\\Escape_Room\\sound\\Main_bgm.wav",true);
					new IN_GAME();
				}		
			});	  	
		}
}

/************************************************************************************************************
* 							                     	ȭ���
* ***********************************************************************************************************/

class Toilet {
	static	ImagePanel Toilet_In=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Toilet_In.png").getImage());//���� ȭ�� �̹��� �ҷ�����
	static	ImagePanel Toilet_Door=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Toilet_Door.png").getImage());//���� ȭ�� �̹��� �ҷ�����
	static	ImagePanel Floor4_Toilet=new ImagePanel(new ImageIcon("C:/Escape_project/Escape_Room/image/Floor4_Toilet.png").getImage());//���� ȭ�� �̹��� �ҷ�����
	JButton button=new JButton();
	JButton button2=new JButton();
	public  int f=2;
	static int c=-1;
	static Clip clip;
	JButton BackButton=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));
	JButton BackButt2=new JButton(new ImageIcon("C:\\Escape_project\\Escape_Room\\image\\Left_Shifting_Button.png"));
	static JButton phone=new JButton(new ImageIcon("C:/Escape_project/Escape_Room/image/Inventory_CellPhone.png"));
	static JButton phone2=new JButton(new ImageIcon("C:/Escape_project/Escape_Room/image/Inventory_CellPhone.png"));
	static JButton key1=new JButton(new ImageIcon("C:/Escape_project/Escape_Room/image/Gate_Key1.png"));
	static JButton Inven_key1=new JButton(new ImageIcon("C:/Escape_project/Escape_Room/image/Inventory_Gate_Key1.png"));

	Toilet()
	{
		JButton button=new JButton();
		button.setBounds(337,250,38,90);
		button.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		button.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		button.setFocusPainted(false);
				
		phone2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		phone2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		phone2.setFocusPainted(false);
		Inven_key1.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		Inven_key1.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		Inven_key1.setFocusPainted(false);
		key1.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		key1.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		key1.setFocusPainted(false);
			
		JButton button2=new JButton();
		button2.setBounds(220,35,400,3700);
		button2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		button2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		button2.setFocusPainted(false);
			
		key1.setBounds(350,200,60,60);
		BackButton.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButton.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButton.setFocusPainted(false);
		BackButton.setBounds(-25, 510, 141, 38);
		BackButt2.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
		BackButt2.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
		BackButt2.setFocusPainted(false);
		BackButt2.setBounds(-25, 510, 141, 38);
	 
		EscapeM.frame.getContentPane().removeAll();
		EscapeM.frame.getContentPane().update( EscapeM.frame.getContentPane().getGraphics());
	    EscapeM.object =new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
					,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,button,BackButt2,Toilet_In};
		EscapeM.Map_Move(EscapeM.object);
		
		BackButt2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Floor4_Hallway(false); 	
				}
			});
		
		BackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				if(f==0) {	
					new Toilet();
		    		f=2;
		    	}
				else{
					EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
								,setInventory.sixth,setInventory.sventh,setInventory.eighth,C817.ItemPanel,button2,BackButton,Toilet_Door};
				    EscapeM.Map_Move(EscapeM.object);
	                f=0;             
	                }
				}
			});
		
		    button.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent arg0) {
		    		EscapeM.object=null;
					EscapeM.object=new Object[] {setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,button2,C817.ItemPanel,BackButton,Toilet_Door};
					EscapeM.Map_Move(EscapeM.object);
					}
		    	});
		    
		   phone.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					new setInventory(phone2);
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	  
					EscapeM.frame.getContentPane().remove(phone);
					EscapeM.frame.getContentPane().repaint();
					
				}
		    });
		   
		   key1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					new setInventory(Inven_key1);
					File file = new File("C:\\Escape_project\\Escape_Room\\sound\\������ȹ��.wav");
				     System.out.println(file.exists()); //true
				     
				     try {
				         AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				         clip= AudioSystem.getClip();
				         clip.open(stream);
				         clip.start();       
				     } catch(Exception e) {	         
				         e.printStackTrace();
				     }	  
					C817.END_KEY2=1; 
					EscapeM.frame.getContentPane().remove(key1);
					EscapeM.frame.getContentPane().repaint();	
				}
		    });
		   
		   button2.addActionListener(new ActionListener() {
			   public void actionPerformed(ActionEvent arg0) {
				    EscapeM.object=null;
				    phone.setContentAreaFilled(false);//��ư �� �����ϰ� �ϱ�
					phone.setBorderPainted(false);//��ư �� �� �����ϰ� �ϱ�
					phone.setFocusPainted(false);
					phone.setBounds(390,190,60,60);
			
				    EscapeM.object=new Object[] {key1,phone,setInventory.first,setInventory.second,setInventory.third,setInventory.fourth,setInventory.fifth
							,setInventory.sixth,setInventory.sventh,setInventory.eighth,BackButton,C817.ItemPanel,Floor4_Toilet};
				    EscapeM.Map_Move(EscapeM.object);
				 }
			  });
		   }
}